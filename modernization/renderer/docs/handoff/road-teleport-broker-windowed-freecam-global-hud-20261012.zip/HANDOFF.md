# Master Rallye graphics and recovery handoff

Created: 2026-10-12
Repository branch: `master`
Base HEAD: `0439afe551e6555eadb97b9ae91651406690640e`
Source state: current worktree snapshot, including uncommitted Global HUD Hide follow-up changes.

This archive consolidates the current renderer source, tests, build configuration and evidence documents for the Road Teleport work, Broker NULL Dump Guard, Windowed Freecam Reset/input fix, and Global HUD Hide (including replay, Attract Demo and startup countdown coverage). Shared renderer sources are included as a complete current snapshot because these features use common lifecycle, wrapper, input and configuration code. This is a source handoff, not a patch against HEAD.

The user has reported that the latest behavior works. The included automated validation records are preserved with their scope; they should not be read as substitutes for runtime evidence.

## Contents

- `modernization/renderer/include`, `src`, `tests`, `tools`, and `vendor`: production code, native and Python regression tests, build/verifier tooling, and required vendored source headers.
- Renderer build files and example INI.
- Stage evidence and handoff documents for Road Teleport, Broker NULL Guard / Windowed Freecam, Observatory compatibility, and Global HUD Hide.
- `MANIFEST.sha256`: SHA-256 for each included source/document file.

## Exclusions

No proprietary game executable/assets, generated DLL or other build output, runtime JSONL/logs, reverse-engineering databases, or nested historical ZIP archives are included.

## Rebuild and test

From the repository root, use `python modernization/renderer/tools/build.py`, then run `python -m unittest discover -s modernization/renderer/tests -v` and `python -m unittest discover -s tests/synthetic -v`. Build/test outcome details and runtime handoffs are in the stage documents.

## Source worktree status at packaging

```text
M modernization/renderer/docs/global-hud-hide/implementation.md
 M modernization/renderer/docs/global-hud-hide/runtime-handoff.md
 M modernization/renderer/docs/global-hud-hide/source-archive-manifest.md
 M modernization/renderer/docs/global-hud-hide/validation.md
 M modernization/renderer/include/hud_visibility.hpp
 M modernization/renderer/include/race_epoch.hpp
 M modernization/renderer/src/hud_visibility.cpp
 M modernization/renderer/src/race_epoch.cpp
 M modernization/renderer/src/race_observer.cpp
 M modernization/renderer/src/visual_wrappers.cpp
 M modernization/renderer/tests/hud_visibility_tests.cpp
 M modernization/renderer/tests/race_epoch_tests.cpp
?? modernization/renderer/docs/global-hud-hide/attract-countdown-source.zip
```
