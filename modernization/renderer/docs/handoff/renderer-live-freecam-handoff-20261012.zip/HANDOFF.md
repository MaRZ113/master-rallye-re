# Master Rallye renderer handoff — Live Freecam

Created: 2026-10-12
Repository: `master-rallye-re-general`
Branch: `master`
Base HEAD: `0439afe551e6555eadb97b9ae91651406690640e`

This source snapshot extends the prior Road Teleport, Broker NULL Guard, Windowed Freecam, and Global HUD Hide handoff with opt-in Live Freecam while the native race simulation is running. It includes the current shared renderer source, regression tests, build tooling, and stage documentation. It is a source handoff, not a patch against HEAD.

The implementation is `LIVE_FREECAM_READY_FOR_RUNTIME`: automated checks and PE validation pass, while visual confirmation that the vehicle and AI continue advancing during camera flight remains a human runtime test. The opt-in setting is `FreeCamera.AllowUnpaused=1`; the shipped example defaults it to `0`. The current local test INI is outside this archive and outside the repository.

## Contents

- Current renderer headers, source, tests, tools, build files, and required vendored headers.
- Previous stage evidence and handoffs, plus `modernization/renderer/docs/live-freecam/`.
- `MANIFEST.sha256`: SHA-256 for every packaged file except the manifest itself.

## Exclusions

No game executable/assets, generated DLL or other build outputs, runtime JSONL/logs, reverse-engineering databases, or nested ZIP archives are included.

## Rebuild and test

From the repository root, run `python modernization/renderer/tools/build.py`, `python -m unittest discover -s modernization/renderer/tests -v`, and `python -m unittest discover -s tests/synthetic -v`. The current candidate and actual results are documented in `modernization/renderer/docs/live-freecam/validation.md`.
