# Live Freecam runtime handoff

Use `D:\Game\Master Rallye\master-rallye-re-general\modernization\renderer\.build-msvc\Release\d3d8.dll`
(SHA-256
`51f7ba1f6c4b403ad14fbdb6c73661e4f3a01e5ed678f7077cf405066ab94b31`,
2,297,856 bytes) with the exact pristine retail `MRallye.exe` (SHA-256
`bf8aef32407eb6552c05045b8abef149f32983cedd9503b865069b444c5f96b4`). Back
up the currently installed DLL, then copy this candidate beside the game EXE.
The active local INI at `D:\Game\Master Rallye Pristine\MRRRenderer.ini` now
has `[FreeCamera] Enabled=1` and `AllowUnpaused=1`; no other user settings
were replaced. Do not modify the EXE.

1. Start an offline France1 race and leave simulation running. Press F8,
   translate/look around, then stop input. Confirm the Freecam stays in world
   space while the car and AI continue moving. Press F8 again and confirm the
   current stock chase camera returns.
2. Activate F8 while running, note the view, pause, move the camera, then
   resume. Freecam should remain active at its moved pose through both
   transitions. Confirm the race itself advances after resume.
3. While running Freecam, press H and verify Global HUD Hide; use a bookmark.
   Press T while unpaused and verify it is rejected. Pause, then check that the
   existing Road Teleport arm path still requires its normal gates. Clean View
   remains available only through its prior paused-Freecam policy.
4. If practical, repeat in Windowed mode, maximize/restore once, and verify
   Freecam remains safely deactivated across a graphics Reset and can be
   reactivated after the live race proof is revalidated. Check focus loss,
   cursor restoration, and normal exit.

With tracing enabled, attach one session JSONL and one F10 capture. Look for
`freecam_transition` values `freecam_activated_running`,
`freecam_running_to_paused`, and `freecam_paused_to_running`; verify
`freecam_admission_accepted=true`, `live_simulation_camera_active=true` while
running, unchanged race generation/owner lifetime, and successful camera scope
restoration. `road_teleport` must still reject an unpaused T request. Confirm
physical vehicle/AI motion directly; a zero pause field alone is not proof that
physics advanced.

