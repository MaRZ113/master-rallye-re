#include "visual_policy.hpp"
#include "provenance.hpp"
#include "free_camera.hpp"
#include <algorithm>
#include <cmath>
#include <cerrno>
#include <cstdlib>
#include <cctype>
#include <sstream>
#include <cfenv>
namespace gfx2 {
namespace {
struct PolicyFP {fenv_t env;PolicyFP(){fegetenv(&env);}~PolicyFP(){fesetenv(&env);}};
std::string trim(std::string v){auto a=v.find_first_not_of(" \t\r\n");return a==std::string::npos?"":v.substr(a,v.find_last_not_of(" \t\r\n")-a+1);}
bool number(const std::string& text,double& out){auto v=trim(text);char* end=nullptr;errno=0;out=std::strtod(v.c_str(),&end);return !v.empty()&&end==v.c_str()+v.size()&&!errno&&std::isfinite(out);}
}
bool parse_config_boolean(std::string v,bool& out){v=trim(v);for(char& c:v)c=static_cast<char>(std::tolower(static_cast<unsigned char>(c)));if(v=="true"||v=="1"){out=true;return true;}if(v=="false"||v=="0"){out=false;return true;}return false;}
VisualConfig parse_visual_config(const std::unordered_map<std::string,std::string>& fields,bool found){
 PolicyFP fp;VisualConfig c;c.found=found;c.raw_fields.insert(fields.begin(),fields.end());if(!found){c.reason="missing_config_stock";return c;}
 auto get=[&](const char* key,const char* fallback){auto i=fields.find(key);return i==fields.end()?std::string(fallback):i->second;};
 c.version_ok=trim(get("Renderer.ConfigVersion",""))=="1";
 if(!c.version_ok){c.reason="unknown_or_missing_config_version_stock";return c;}
 c.reason="version_1";
 if(!parse_config_boolean(get("HUD.ToggleEnabled","1"),c.hud_toggle_enabled)){c.hud_toggle_enabled=false;c.hud_toggle_valid=false;c.hud_reason="invalid_toggle_enabled";}
 if(!parse_config_boolean(get("HUD.HiddenAtStartup","0"),c.hud_hidden_at_startup)){c.hud_hidden_at_startup=false;c.hud_toggle_valid=false;c.hud_reason="invalid_hidden_at_startup";}
 // PreserveMenus is a safety invariant. The setting is read for diagnostics,
 // but a false value can never authorize hiding frontend or interactive UI.
 bool preserve_menus=true;if(!parse_config_boolean(get("HUD.PreserveMenus","1"),preserve_menus)||!preserve_menus){c.hud_preserve_menus=true;c.hud_reason="preserve_menus_enforced";}
 auto hud_key=fields.find("HUD.ToggleKey");auto legacy_clean_key=fields.find("FreeCameraKeys.ToggleCleanView");
 const std::string hud_key_text=hud_key!=fields.end()?hud_key->second:legacy_clean_key!=fields.end()?legacy_clean_key->second:"H";
 c.hud_toggle_key=free_camera_key(hud_key_text);
 if(!c.hud_toggle_key||c.hud_toggle_key==VK_F10){c.hud_toggle_valid=false;c.hud_toggle_enabled=false;c.hud_reason="invalid_or_reserved_toggle_key";}
 const char* feature_keys[]={"FreeCamera.ToggleKey","FreeCameraKeys.SaveCameraBookmark","FreeCameraKeys.LoadCameraBookmark","FreeCameraKeys.NextCameraBookmarkSlot","FreeCameraKeys.SpeedIncrease","FreeCameraKeys.SpeedDecrease","FreeCameraKeys.FOVDecrease","FreeCameraKeys.FOVIncrease","FreeCameraKeys.RollLeft","FreeCameraKeys.RollRight","FreeCameraKeys.RollReset","FreeCameraKeys.ArmRoadTeleport","FreeCameraKeys.Forward","FreeCameraKeys.Backward","FreeCameraKeys.Left","FreeCameraKeys.Right","FreeCameraKeys.Up","FreeCameraKeys.Down","FreeCameraKeys.Fast","FreeCameraKeys.Slow"};
 const char* feature_defaults[]={"F8","J","K","L","PageUp","PageDown","Z","X","C","V","B","T","W","S","A","D","E","Q","LeftShift","LeftAlt"};
 for(size_t i=0;i<sizeof(feature_keys)/sizeof(feature_keys[0]);++i){auto it=fields.find(feature_keys[i]);if(free_camera_key(it==fields.end()?feature_defaults[i]:it->second)==c.hud_toggle_key){c.hud_toggle_valid=false;c.hud_toggle_enabled=false;c.hud_reason="toggle_conflicts_with_free_camera_binding";break;}}
 // The legacy Clean View key is an alias for this one preference and is
 // deliberately excluded from conflict checks.
 if(c.hud_toggle_valid&&c.hud_reason=="default_h")c.hud_reason=hud_key!=fields.end()?"hud_key_configured":legacy_clean_key!=fields.end()?"legacy_clean_view_key_alias":"default_h";
 // Keep legacy CleanViewEnabled behavior as a startup preference only when
 // the new explicit HUD.HiddenAtStartup field is absent.
 if(fields.find("HUD.HiddenAtStartup")==fields.end()){
  bool legacy_start=false;if(parse_config_boolean(get("FreeCamera.CleanViewEnabled","0"),legacy_start)&&legacy_start)c.hud_hidden_at_startup=true;
 }
 auto foliage=get("PS2FoliagePilot.Mode","0");
 if(trim(foliage)=="1"){c.foliage_mode=1;c.foliage_reason="blocked_on_draw_identity";}
 else if(trim(foliage)!="0")c.foliage_reason="invalid_foliage_mode_stock";
 if(!parse_config_boolean(get("PS2FoliagePilot.Diagnostics","0"),c.foliage_diagnostics))c.foliage_diagnostics=false;
 if(!parse_config_boolean(get("Filtering.AnisotropicFiltering","false"),c.anisotropy)){c.anisotropy=false;c.af_reason="invalid_boolean";}
 double n=0;if(!number(get("Filtering.MaxAnisotropy","16"),n)||n<1||n>65535||n!=std::floor(n)){c.anisotropy=false;c.af_reason="invalid_max_anisotropy";}else c.max_anisotropy=static_cast<unsigned>(n);
 if(!parse_config_boolean(get("Camera.GameplayFOV","false"),c.fov)){c.fov=false;c.fov_reason="invalid_boolean";}
 if(!number(get("Camera.VerticalFOVDegrees","75"),n)||n<30||n>110){c.fov=false;c.fov_reason="invalid_vertical_fov";}else c.vfov=static_cast<float>(n);
 auto selector=[&](const char* key,std::initializer_list<const char*> names){auto v=trim(get(key,"Stock"));unsigned i=0;for(auto name:names){if(v==std::to_string(i++))return std::string(name);}return v;};
 auto mode=selector("Shadows.Mode",{"Stock","Off"});if(mode=="Off")c.shadow_off=true;else if(mode!="Stock")c.shadow_reason="invalid_shadow_mode";
 auto reflection=selector("VehicleReflections.Mode",{"Stock","ViewDependent2D"});
 if(reflection=="Stock"||reflection=="ViewDependent2D")c.reflection_mode=reflection;else c.reflection_reason="invalid_reflection_mode_stock";
 auto display=selector("Display.Mode",{"Stock","Windowed","Borderless","ExclusiveFullscreen"});
 if(display=="Stock"||display=="Windowed"||display=="Borderless"||display=="ExclusiveFullscreen")c.display_mode=display;else c.display_reason="invalid_display_mode_stock";
 auto integer=[&](const char* key,const char* fallback,unsigned limit,unsigned& value){double v=0;if(!number(get(key,fallback),v)||v<0||v>limit||v!=std::floor(v))return false;value=static_cast<unsigned>(v);return true;};
 if(!integer("Display.Width","0",16384,c.width)||!integer("Display.Height","0",16384,c.height)||
    ((c.width==0)!=(c.height==0))||(c.width&& (c.width<320||c.height<200))||!integer("Display.RefreshRate","0",1000,c.refresh)){
  c.display_mode="Stock";c.width=c.height=c.refresh=0;c.display_reason="invalid_display_dimensions_or_refresh_stock";
 }
 auto ui=selector("Widescreen.InterfaceMode",{"Stock","Centered4x3","PreserveMargins"});
 if(ui=="Stock"||ui=="Centered4x3"||ui=="PreserveMargins")c.interface_mode=ui;else c.interface_reason="invalid_interface_mode_stock";
 auto aa=selector("AntiAliasing.Mode",{"Stock","MSAA"});if(aa=="Stock"||aa=="MSAA")c.aa_mode=aa;else c.aa_reason="invalid_aa_mode_stock";
 if(!integer("AntiAliasing.Samples","4",8,c.samples)||(c.samples!=2&&c.samples!=4&&c.samples!=8)){c.aa_mode="Stock";c.samples=4;c.aa_reason="invalid_samples_stock";}
 if(!parse_config_boolean(get("Compatibility.MenuFreezeFix","false"),c.menu_freeze)){c.menu_freeze=false;c.freeze_reason="invalid_freeze_boolean_disabled";}
 if(!parse_config_boolean(get("Display.AutoHideCursor","1"),c.auto_hide_cursor)){c.auto_hide_cursor=false;c.cursor_reason="invalid_cursor_boolean_disabled";}
 if(!integer("Display.CursorHideDelayMs","1500",60000,c.cursor_delay_ms)){c.auto_hide_cursor=false;c.cursor_reason="invalid_cursor_delay_disabled";}
 return c;
}
VisualConfig read_visual_config(const std::wstring& path){
 auto attributes=GetFileAttributesW(path.c_str());bool found=attributes!=INVALID_FILE_ATTRIBUTES&&!(attributes&FILE_ATTRIBUTE_DIRECTORY);
 std::unordered_map<std::string,std::string> fields;
 if(found){
  struct Key{const wchar_t* section;const wchar_t* key;const char* name;};
  const Key keys[]={{L"Renderer",L"ConfigVersion","Renderer.ConfigVersion"},{L"Filtering",L"AnisotropicFiltering","Filtering.AnisotropicFiltering"},{L"Filtering",L"MaxAnisotropy","Filtering.MaxAnisotropy"},{L"Camera",L"GameplayFOV","Camera.GameplayFOV"},{L"Camera",L"VerticalFOVDegrees","Camera.VerticalFOVDegrees"},{L"Shadows",L"Mode","Shadows.Mode"},{L"VehicleReflections",L"Mode","VehicleReflections.Mode"}};
  const Key quality_keys[]={{L"PS2FoliagePilot",L"Mode","PS2FoliagePilot.Mode"},{L"PS2FoliagePilot",L"Diagnostics","PS2FoliagePilot.Diagnostics"},{L"Display",L"AutoHideCursor","Display.AutoHideCursor"},{L"Display",L"CursorHideDelayMs","Display.CursorHideDelayMs"},{L"Display",L"Mode","Display.Mode"},{L"Display",L"Width","Display.Width"},{L"Display",L"Height","Display.Height"},{L"Display",L"RefreshRate","Display.RefreshRate"},{L"Widescreen",L"InterfaceMode","Widescreen.InterfaceMode"},{L"AntiAliasing",L"Mode","AntiAliasing.Mode"},{L"AntiAliasing",L"Samples","AntiAliasing.Samples"},{L"Compatibility",L"MenuFreezeFix","Compatibility.MenuFreezeFix"},{L"HUD",L"ToggleEnabled","HUD.ToggleEnabled"},{L"HUD",L"ToggleKey","HUD.ToggleKey"},{L"HUD",L"HiddenAtStartup","HUD.HiddenAtStartup"},{L"HUD",L"PreserveMenus","HUD.PreserveMenus"}};
   const Key flight_keys[]={{L"FreeCamera",L"Enabled","FreeCamera.Enabled"},{L"FreeCamera",L"AllowUnpaused","FreeCamera.AllowUnpaused"},{L"FreeCamera",L"ControlPreset","FreeCamera.ControlPreset"},{L"FreeCamera",L"ToggleKey","FreeCamera.ToggleKey"},{L"FreeCamera",L"MoveSpeed","FreeCamera.MoveSpeed"},{L"FreeCamera",L"MinMoveSpeed","FreeCamera.MinMoveSpeed"},{L"FreeCamera",L"MaxMoveSpeed","FreeCamera.MaxMoveSpeed"},{L"FreeCamera",L"WheelSpeedFactor","FreeCamera.WheelSpeedFactor"},{L"FreeCamera",L"MovementSmoothSeconds","FreeCamera.MovementSmoothSeconds"},{L"FreeCamera",L"FastMultiplier","FreeCamera.FastMultiplier"},{L"FreeCamera",L"SlowMultiplier","FreeCamera.SlowMultiplier"},{L"FreeCamera",L"MouseSensitivity","FreeCamera.MouseSensitivity"},{L"FreeCamera",L"AutoLevelHorizon","FreeCamera.AutoLevelHorizon"},{L"FreeCamera",L"HorizonLevelSeconds","FreeCamera.HorizonLevelSeconds"},{L"FreeCamera",L"CinematicFOVEnabled","FreeCamera.CinematicFOVEnabled"},{L"FreeCamera",L"CinematicVerticalFOVDegrees","FreeCamera.CinematicVerticalFOVDegrees"},{L"FreeCamera",L"MinVerticalFOVDegrees","FreeCamera.MinVerticalFOVDegrees"},{L"FreeCamera",L"MaxVerticalFOVDegrees","FreeCamera.MaxVerticalFOVDegrees"},{L"FreeCamera",L"FOVStepDegrees","FreeCamera.FOVStepDegrees"},{L"FreeCamera",L"FOVSmoothSeconds","FreeCamera.FOVSmoothSeconds"},{L"FreeCamera",L"ManualRollEnabled","FreeCamera.ManualRollEnabled"},{L"FreeCamera",L"RollSpeedDegreesPerSecond","FreeCamera.RollSpeedDegreesPerSecond"},{L"FreeCamera",L"RollSmoothSeconds","FreeCamera.RollSmoothSeconds"},{L"FreeCamera",L"MaxRollDegrees","FreeCamera.MaxRollDegrees"},{L"FreeCamera",L"CameraBookmarksEnabled","FreeCamera.CameraBookmarksEnabled"},{L"FreeCamera",L"CameraBookmarkDefaultSlot","FreeCamera.CameraBookmarkDefaultSlot"},{L"FreeCamera",L"CleanViewPilot","FreeCamera.CleanViewPilot"},{L"FreeCamera",L"CleanViewEnabled","FreeCamera.CleanViewEnabled"},{L"FreeCamera",L"VehicleTeleportEnabled","FreeCamera.VehicleTeleportEnabled"},{L"FreeCamera",L"VehicleTeleportRoadOnly","FreeCamera.VehicleTeleportRoadOnly"},{L"FreeCamera",L"VehicleTeleportArmTimeoutSeconds","FreeCamera.VehicleTeleportArmTimeoutSeconds"},{L"FreeCamera",L"VehicleTeleportMaxRoadDistance","FreeCamera.VehicleTeleportMaxRoadDistance"},{L"FreeCameraKeys",L"ArmRoadTeleport","FreeCameraKeys.ArmRoadTeleport"},{L"FreeCameraKeys",L"ToggleCleanView","FreeCameraKeys.ToggleCleanView"},{L"FreeCameraKeys",L"SaveCameraBookmark","FreeCameraKeys.SaveCameraBookmark"},{L"FreeCameraKeys",L"LoadCameraBookmark","FreeCameraKeys.LoadCameraBookmark"},{L"FreeCameraKeys",L"NextCameraBookmarkSlot","FreeCameraKeys.NextCameraBookmarkSlot"},{L"FreeCameraKeys",L"SpeedIncrease","FreeCameraKeys.SpeedIncrease"},{L"FreeCameraKeys",L"SpeedDecrease","FreeCameraKeys.SpeedDecrease"},{L"FreeCameraKeys",L"FOVDecrease","FreeCameraKeys.FOVDecrease"},{L"FreeCameraKeys",L"FOVIncrease","FreeCameraKeys.FOVIncrease"},{L"FreeCameraKeys",L"RollLeft","FreeCameraKeys.RollLeft"},{L"FreeCameraKeys",L"RollRight","FreeCameraKeys.RollRight"},{L"FreeCameraKeys",L"RollReset","FreeCameraKeys.RollReset"},{L"FreeCameraKeys",L"Forward","FreeCameraKeys.Forward"},{L"FreeCameraKeys",L"Backward","FreeCameraKeys.Backward"},{L"FreeCameraKeys",L"Left","FreeCameraKeys.Left"},{L"FreeCameraKeys",L"Right","FreeCameraKeys.Right"},{L"FreeCameraKeys",L"Up","FreeCameraKeys.Up"},{L"FreeCameraKeys",L"Down","FreeCameraKeys.Down"},{L"FreeCameraKeys",L"Fast","FreeCameraKeys.Fast"},{L"FreeCameraKeys",L"Slow","FreeCameraKeys.Slow"}};
  auto read=[&](const Key& k){wchar_t b[256];DWORD n=GetPrivateProfileStringW(k.section,k.key,L"__ABSENT__",b,256,path.c_str());if(n>=255)fields[k.name]="__TRUNCATED_INVALID__";else if(wcscmp(b,L"__ABSENT__"))fields[k.name]=utf8(b);};
  for(const auto& k:keys)read(k);for(const auto& k:quality_keys)read(k);for(const auto& k:flight_keys)read(k);
 }
 return parse_visual_config(fields,found);
}
std::string config_json(const VisualConfig& c){std::ostringstream o;o<<"{\"config_found\":"<<(c.found?"true":"false")<<",\"ConfigVersion\":"<<(c.version_ok?"1":"null")<<",\"anisotropy\":"<<(c.anisotropy?"true":"false")<<",\"max_anisotropy\":"<<c.max_anisotropy<<",\"gameplay_fov\":"<<(c.fov?"true":"false")<<",\"vfov\":"<<c.vfov<<",\"shadow\":"<<quote(c.shadow_off?"Off":"Stock")<<",\"reason\":"<<quote(c.reason)<<",\"af_reason\":"<<quote(c.af_reason)<<",\"fov_reason\":"<<quote(c.fov_reason)<<",\"shadow_reason\":"<<quote(c.shadow_reason)<<",\"vehicle_reflections\":"<<quote(c.reflection_mode)<<",\"reflection_reason\":"<<quote(c.reflection_reason)<<",\"hud_toggle_enabled\":"<<(c.hud_toggle_enabled?"true":"false")<<",\"hud_toggle_key\":"<<c.hud_toggle_key<<",\"hud_hidden_at_startup\":"<<(c.hud_hidden_at_startup?"true":"false")<<",\"hud_preserve_menus\":"<<(c.hud_preserve_menus?"true":"false")<<",\"hud_toggle_valid\":"<<(c.hud_toggle_valid?"true":"false")<<",\"hud_reason\":"<<quote(c.hud_reason)<<",\"display_mode\":"<<quote(c.display_mode)<<",\"auto_hide_cursor\":"<<(c.auto_hide_cursor?"true":"false")<<",\"cursor_hide_delay_ms\":"<<c.cursor_delay_ms<<",\"cursor_reason\":"<<quote(c.cursor_reason)<<",\"display_width\":"<<c.width<<",\"display_height\":"<<c.height<<",\"refresh_rate\":"<<c.refresh<<",\"display_reason\":"<<quote(c.display_reason)<<",\"interface_mode\":"<<quote(c.interface_mode)<<",\"interface_reason\":"<<quote(c.interface_reason)<<",\"aa_mode\":"<<quote(c.aa_mode)<<",\"aa_samples\":"<<c.samples<<",\"aa_reason\":"<<quote(c.aa_reason)<<",\"menu_freeze_fix\":"<<(c.menu_freeze?"true":"false")<<",\"freeze_reason\":"<<quote(c.freeze_reason)<<",\"ps2_foliage_mode\":"<<c.foliage_mode<<",\"ps2_foliage_diagnostics\":"<<(c.foliage_diagnostics?"true":"false")<<",\"ps2_foliage_reason\":"<<quote(c.foliage_reason)<<",\"raw_fields\":{";bool first=true;for(const auto& entry:c.raw_fields){if(!first)o<<',';first=false;o<<quote(entry.first)<<':'<<quote(entry.second);}o<<"}}";return o.str();}
void VisualPolicy::configure(const VisualConfig& c,bool known,const D3DCAPS8* caps,HRESULT hr){
 requested=c;effective=c;caps_result=hr;
 effective.foliage_mode=0; // No runtime identity approval exists in this diagnostic checkpoint.
 effective.foliage_reason=c.foliage_mode?"blocked_on_draw_identity":c.foliage_reason;
 if(!known){effective.foliage_diagnostics=false;effective.foliage_reason="unsupported_build_stock";}
 if(c.reflection_mode=="ViewDependent2D")effective.reflection_reason="requires_live_or_learned_body_proof_current_material";
 if(!known){effective.fov=effective.shadow_off=false;effective.reason="feature_local_compatibility";effective.reflection_mode="Stock";effective.reflection_reason="unsupported_build";}
 // Game-specific quality capabilities are applied by the device/root owners.
 // AF is purely D3D-generic and still goes through actual device capability checks.
 if(effective.anisotropy){
  if(caps&&SUCCEEDED(hr)){caps_max=caps->MaxAnisotropy;min_supported=(caps->TextureFilterCaps&D3DPTFILTERCAPS_MINFANISOTROPIC)!=0;mag_supported=(caps->TextureFilterCaps&D3DPTFILTERCAPS_MAGFANISOTROPIC)!=0;}
  if(!caps||FAILED(hr)||caps_max<2||!min_supported){effective.anisotropy=false;effective.af_reason="unsupported_min_anisotropy_or_caps_query_failed";}
  else effective.max_anisotropy=std::min(c.max_anisotropy,static_cast<unsigned>(caps_max));
 }
}
DWORD VisualPolicy::filter(DWORD stage,D3DTEXTURESTAGESTATETYPE type,DWORD value) const noexcept {
 if(!effective.anisotropy||stage!=0)return value;
 if(type==D3DTSS_MAXANISOTROPY&&value>0)return effective.max_anisotropy;
 if(value!=D3DTEXF_LINEAR)return value;
 if(type==D3DTSS_MINFILTER&&min_supported)return D3DTEXF_ANISOTROPIC;
 return value;
}
bool symmetric_lh(const D3DMATRIX& p) noexcept {
 const float* f=&p.m[0][0];for(int i=0;i<16;++i){if(!std::isfinite(f[i]))return false;if(i!=0&&i!=5&&i!=10&&i!=11&&i!=14&&f[i]!=0.f)return false;}
 return p._11>0.f&&p._22>0.f&&p._33>1.f&&p._34==1.f&&p._43<0.f;
}
float vertical_fov(const D3DMATRIX& p) noexcept {PolicyFP fp;return static_cast<float>(2.*std::atan(1./p._22)*180./3.14159265358979323846);}
double source_camera_angle(const D3DMATRIX& p) noexcept {
 PolicyFP fp;if(!symmetric_lh(p))return 0.;
 const double aspect=static_cast<double>(p._22)/p._11;
 // Original helper 004F2350 scales authored angle by H/W only for landscape.
 return 2.*std::atan(1./p._22)*180./3.14159265358979323846*std::max(1.,aspect);
}
bool VisualPolicy::projection(D3DTRANSFORMSTATETYPE type,const D3DMATRIX* input,D3DMATRIX& out,bool exe_caller,uint32_t rva,float vfov_override) const noexcept {
 PolicyFP fp;
 float selected_vfov=vfov_override>0?vfov_override:effective.vfov;
 if((!effective.fov&&vfov_override<=0)||type!=D3DTS_PROJECTION||!exe_caller||rva!=GAMEPLAY_PROJECTION_RETURN_RVA||!input||!std::isfinite(selected_vfov)||selected_vfov<30||selected_vfov>110||!safe_copy(&out,input,sizeof(out))||!symmetric_lh(out))return false;
 if(std::abs(source_camera_angle(out)-90.)>SOURCE_CAMERA_TOLERANCE_DEGREES)return false;
 double aspect=static_cast<double>(out._22)/out._11;double y=1./std::tan(selected_vfov*3.14159265358979323846/360.);
 if(!std::isfinite(aspect)||aspect<=0||!std::isfinite(y))return false;
 out._11=static_cast<float>(y/aspect);out._22=static_cast<float>(y);return std::isfinite(out._11)&&out._11>0&&std::isfinite(out._22)&&out._22>0;
}
bool VisualPolicy::suppress(uint32_t slot,bool exe_caller,uint32_t rva,const Shadow& s,D3DPRIMITIVETYPE primitive) const noexcept {
 return effective.shadow_off&&slot==70&&exe_caller&&rva==STOCK_SHADOW_RETURN_RVA&&primitive==D3DPT_TRIANGLELIST&&
 s.rs[27].known&&s.rs[27].value==1&&s.rs[28].known&&s.rs[28].value==0&&s.rs[14].known&&s.rs[14].value==0&&
 s.bindings.vertex_shader.known&&s.bindings.vertex_shader.value==0x142;
}
}
