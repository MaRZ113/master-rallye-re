#pragma once

#include <array>
#include <cstddef>
#include <cstdint>

namespace gfx2::physics_probe {

inline constexpr uint32_t CONTROLLER_CALL_VA = 0x00443827;
inline constexpr uint32_t CONTROLLER_CALL_TARGET_VA = 0x00444AE0;
inline constexpr uint32_t SUBSTEP_BEGIN_CALL_VA = 0x0043F8AD;
inline constexpr uint32_t SUBSTEP_BEGIN_TARGET_VA = 0x0043F650;
inline constexpr uint32_t SUBSTEP_TAIL_CALL_VA = 0x0043F8ED;
inline constexpr uint32_t SUBSTEP_TAIL_TARGET_VA = 0x0043FE00;
inline constexpr size_t MAX_TRACKS = 8;
inline constexpr size_t MAX_EVENTS = 64;
inline constexpr uint32_t SUBSTEP_WINDOW_EVENTS = 24;
inline constexpr uint8_t MAX_FLAGGED_SAMPLES = 4;
inline constexpr uint8_t SETTLING_SAMPLES = 3;

enum class OwnerClass : uint8_t { Unknown, HumanCandidate, AiCandidate };
OwnerClass owner_class(uint32_t player_type) noexcept;

struct NativeLinks {
    uint32_t controller = 0;
    uint32_t handle = 0;
    uint32_t handle_controller = 0;
    uint32_t actor = 0;
    uint32_t body = 0;
    uint32_t backing = 0;
    uint32_t wheel_records = 0;
    uint32_t player_type = 0;
};

bool pointer_shape(uint32_t pointer) noexcept;
bool links_valid(const NativeLinks& links) noexcept;
bool same_identity(const NativeLinks& a, const NativeLinks& b) noexcept;
bool encode_relative_call(uint32_t site_va, uint32_t target_va,
                          std::array<uint8_t, 5>& output) noexcept;

enum class FlagEvent : uint8_t {
    None,
    FirstSetObserved,
    SetEdge,
    RepeatedSet,
    ClearEdge,
    Settling
};

struct FlagTracker {
    bool known = false;
    bool set = false;
    uint8_t captured_set_samples = 0;
    uint8_t settling_remaining = 0;
    uint64_t calls = 0;
    uint64_t set_calls = 0;
    uint64_t rises = 0;
    uint64_t clears = 0;
};

FlagEvent observe_flag(FlagTracker& tracker, uint8_t value) noexcept;
bool reserve_bounded_slot(size_t& used, size_t capacity) noexcept;
const char* flag_event_name(FlagEvent event) noexcept;

} // namespace gfx2::physics_probe
