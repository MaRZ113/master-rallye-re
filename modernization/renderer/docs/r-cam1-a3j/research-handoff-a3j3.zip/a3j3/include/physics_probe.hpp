#pragma once

#include <string>

namespace gfx2 {

struct PhysicsProbeSettings {
    bool enabled = false;
    bool valid = true;
    std::string raw_value = "0";
};

PhysicsProbeSettings read_physics_probe_settings(const std::wstring& path) noexcept;
bool attach_physics_probe(bool exact_retail, const PhysicsProbeSettings& settings) noexcept;
void release_physics_probe() noexcept;

} // namespace gfx2
