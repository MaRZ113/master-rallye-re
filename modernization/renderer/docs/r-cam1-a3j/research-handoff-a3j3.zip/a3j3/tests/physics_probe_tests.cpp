#include "physics_probe_model.hpp"

#include <array>
#include <cstdint>
#include <cstring>

#define CHECK(condition) do { if (!(condition)) return __LINE__; } while (0)

using namespace gfx2::physics_probe;

int main() {
    CHECK(owner_class(1) == OwnerClass::HumanCandidate);
    CHECK(owner_class(2) == OwnerClass::AiCandidate);
    CHECK(owner_class(0) == OwnerClass::Unknown);
    CHECK(owner_class(3) == OwnerClass::Unknown);

    NativeLinks links{0x10000, 0x20000, 0x10000, 0x30000, 0x40000,
                      0x50000, 0x60000, 1};
    CHECK(links_valid(links));
    auto replacement = links;
    replacement.body = 0x70000;
    CHECK(!same_identity(links, replacement));
    replacement = links;
    replacement.handle_controller = 0x11000;
    CHECK(!links_valid(replacement));
    replacement = links;
    replacement.wheel_records = 0x60001;
    CHECK(!links_valid(replacement));

    std::array<uint8_t, 5> call{};
    CHECK(encode_relative_call(CONTROLLER_CALL_VA, CONTROLLER_CALL_TARGET_VA, call));
    CHECK((call == std::array<uint8_t, 5>{0xE8, 0xB4, 0x12, 0x00, 0x00}));
    CHECK(encode_relative_call(SUBSTEP_BEGIN_CALL_VA, SUBSTEP_BEGIN_TARGET_VA, call));
    CHECK((call == std::array<uint8_t, 5>{0xE8, 0x9E, 0xFD, 0xFF, 0xFF}));
    CHECK(encode_relative_call(SUBSTEP_TAIL_CALL_VA, SUBSTEP_TAIL_TARGET_VA, call));
    CHECK((call == std::array<uint8_t, 5>{0xE8, 0x0E, 0x05, 0x00, 0x00}));
    CHECK(!encode_relative_call(0xFFFFFFFCu, 0x00400000u, call));

    FlagTracker flag{};
    CHECK(observe_flag(flag, 0) == FlagEvent::None);
    CHECK(observe_flag(flag, 1) == FlagEvent::SetEdge);
    CHECK(observe_flag(flag, 1) == FlagEvent::RepeatedSet);
    CHECK(observe_flag(flag, 1) == FlagEvent::RepeatedSet);
    CHECK(observe_flag(flag, 1) == FlagEvent::RepeatedSet);
    CHECK(observe_flag(flag, 1) == FlagEvent::None);
    CHECK(observe_flag(flag, 1) == FlagEvent::None);
    CHECK(observe_flag(flag, 0) == FlagEvent::ClearEdge);
    CHECK(observe_flag(flag, 0) == FlagEvent::Settling);
    CHECK(observe_flag(flag, 0) == FlagEvent::Settling);
    CHECK(observe_flag(flag, 0) == FlagEvent::Settling);
    CHECK(observe_flag(flag, 0) == FlagEvent::None);
    CHECK(flag.calls == 12);
    CHECK(flag.set_calls == 6);
    CHECK(flag.rises == 1);
    CHECK(flag.clears == 1);

    FlagTracker initially_set{};
    CHECK(observe_flag(initially_set, 1) == FlagEvent::FirstSetObserved);
    CHECK(initially_set.rises == 1);
    CHECK(std::strcmp(flag_event_name(FlagEvent::ClearEdge), "clear_edge") == 0);

    size_t used = 0;
    CHECK(reserve_bounded_slot(used, 2));
    CHECK(reserve_bounded_slot(used, 2));
    CHECK(!reserve_bounded_slot(used, 2));
    CHECK(used == 2);
    return 0;
}
