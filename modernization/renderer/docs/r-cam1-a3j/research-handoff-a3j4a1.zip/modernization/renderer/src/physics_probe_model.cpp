#include "physics_probe_model.hpp"

#include <cstring>
#include <limits>

namespace gfx2::physics_probe {

OwnerClass owner_class(uint32_t player_type) noexcept {
    if (player_type == 1) return OwnerClass::HumanCandidate;
    if (player_type == 2) return OwnerClass::AiCandidate;
    return OwnerClass::Unknown;
}

bool pointer_shape(uint32_t pointer) noexcept {
    return pointer >= 0x10000u && (pointer & 3u) == 0;
}

bool route_getter_hook_requested(bool observer_enabled,
                                 bool road_preview_enabled) noexcept {
    return observer_enabled && road_preview_enabled;
}

size_t physics_call_patch_count(bool include_route_getter) noexcept {
    return include_route_getter ? 4u : 3u;
}

bool links_valid(const NativeLinks& links) noexcept {
    return pointer_shape(links.controller) && pointer_shape(links.handle) &&
           links.handle_controller == links.controller && pointer_shape(links.actor) &&
           pointer_shape(links.body) && pointer_shape(links.backing) &&
           pointer_shape(links.wheel_records);
}

bool same_identity(const NativeLinks& a, const NativeLinks& b) noexcept {
    return links_valid(a) && links_valid(b) && a.controller == b.controller &&
           a.handle == b.handle && a.actor == b.actor && a.body == b.body &&
           a.backing == b.backing && a.wheel_records == b.wheel_records &&
           a.player_type == b.player_type;
}

bool encode_relative_call(uint32_t site_va, uint32_t target_va,
                          std::array<uint8_t, 5>& output) noexcept {
    output = {};
    if (site_va > std::numeric_limits<uint32_t>::max() - 5u) return false;
    const int64_t displacement = static_cast<int64_t>(target_va) -
                                 static_cast<int64_t>(site_va) - 5;
    if (displacement < std::numeric_limits<int32_t>::min() ||
        displacement > std::numeric_limits<int32_t>::max()) return false;
    const int32_t rel32 = static_cast<int32_t>(displacement);
    output[0] = 0xE8;
    std::memcpy(output.data() + 1, &rel32, sizeof(rel32));
    return true;
}

bool context_bytes_match(const uint8_t* expected, size_t expected_size,
                         const uint8_t* actual, size_t actual_size) noexcept {
    return expected && actual && expected_size != 0 && expected_size == actual_size &&
           std::memcmp(expected, actual, expected_size) == 0;
}

const char* context_failure_reason(bool controller_ok, bool substep_begin_ok,
                                   bool substep_tail_ok) noexcept {
    if (!controller_ok) return "controller_context_mismatch";
    if (!substep_begin_ok) return "substep_begin_context_mismatch";
    if (!substep_tail_ok) return "substep_tail_context_mismatch";
    return nullptr;
}

ClearWriter clear_writer(uint32_t store_va) noexcept {
    switch (store_va) {
    case CLEAR_GATE_STORE_VA: return ClearWriter::GateRejected;
    case CLEAR_RECOVERY_STORE_VA: return ClearWriter::RecoveryMode0;
    case CLEAR_TIMER_STORE_VA: return ClearWriter::TimerExpired;
    default: return ClearWriter::Unknown;
    }
}

const char* clear_writer_name(ClearWriter writer) noexcept {
    switch (writer) {
    case ClearWriter::GateRejected: return "reset_gate_rejected";
    case ClearWriter::RecoveryMode0: return "recovery_mode0";
    case ClearWriter::TimerExpired: return "recovery_timer_expired";
    default: return "unknown";
    }
}

PauseStateAtTime pause_state_at(PauseStateSample sample, uint64_t now_ms,
                                uint64_t maximum_age_ms) noexcept {
    if (!sample.known || !sample.sampled_tick_ms || now_ms < sample.sampled_tick_ms ||
        now_ms - sample.sampled_tick_ms > maximum_age_ms) return {};
    return {true, sample.paused, now_ms - sample.sampled_tick_ms};
}

const char* clear_context_failure_reason(bool gate_ok, bool recovery_ok,
                                        bool timer_ok) noexcept {
    if (!gate_ok) return "clear_gate_context_mismatch";
    if (!recovery_ok) return "clear_recovery_context_mismatch";
    if (!timer_ok) return "clear_timer_context_mismatch";
    return nullptr;
}

FlagEvent observe_flag(FlagTracker& tracker, uint8_t value) noexcept {
    const bool now_set = value != 0;
    ++tracker.calls;
    if (now_set) ++tracker.set_calls;

    if (!tracker.known) {
        tracker.known = true;
        tracker.set = now_set;
        if (now_set) {
            ++tracker.rises;
            tracker.captured_set_samples = 1;
            tracker.settling_remaining = 0;
            return FlagEvent::FirstSetObserved;
        }
        return FlagEvent::None;
    }

    if (!tracker.set && now_set) {
        tracker.set = true;
        ++tracker.rises;
        tracker.captured_set_samples = 1;
        tracker.settling_remaining = 0;
        return FlagEvent::SetEdge;
    }
    if (tracker.set && now_set) {
        if (tracker.captured_set_samples < MAX_FLAGGED_SAMPLES) {
            ++tracker.captured_set_samples;
            return FlagEvent::RepeatedSet;
        }
        return FlagEvent::None;
    }
    if (tracker.set && !now_set) {
        tracker.set = false;
        ++tracker.clears;
        tracker.settling_remaining = SETTLING_SAMPLES;
        return FlagEvent::ClearEdge;
    }
    if (tracker.settling_remaining) {
        --tracker.settling_remaining;
        return FlagEvent::Settling;
    }
    return FlagEvent::None;
}

bool reserve_bounded_slot(size_t& used, size_t capacity) noexcept {
    if (used >= capacity) return false;
    ++used;
    return true;
}

const char* flag_event_name(FlagEvent event) noexcept {
    switch (event) {
    case FlagEvent::FirstSetObserved: return "first_set_observed";
    case FlagEvent::SetEdge: return "set_edge";
    case FlagEvent::RepeatedSet: return "repeated_set";
    case FlagEvent::ClearEdge: return "clear_edge";
    case FlagEvent::Settling: return "settling";
    default: return "none";
    }
}

} // namespace gfx2::physics_probe
