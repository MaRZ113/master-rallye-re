#pragma once

#include <array>
#include <cstddef>
#include <cstdint>

namespace gfx2::physics_probe {

inline constexpr uint32_t CONTROLLER_CALL_VA = 0x00443827;
inline constexpr uint32_t CONTROLLER_CALL_TARGET_VA = 0x00444AE0;
inline constexpr uint32_t SUBSTEP_BEGIN_CALL_VA = 0x0043F8AD;
inline constexpr uint32_t SUBSTEP_BEGIN_TARGET_VA = 0x0043F650;
inline constexpr uint32_t SUBSTEP_TAIL_CALL_VA = 0x0043F8ED;
inline constexpr uint32_t SUBSTEP_TAIL_TARGET_VA = 0x0043FE00;
inline constexpr uint32_t CONTROLLER_CONTEXT_VA = 0x00443820;
inline constexpr uint32_t SUBSTEP_BEGIN_CONTEXT_VA = 0x0043F8A7;
inline constexpr uint32_t SUBSTEP_TAIL_CONTEXT_VA = 0x0043F8DC;
inline constexpr uint32_t ROUTE_GETTER_CALL_VA = 0x004CCCB1;
inline constexpr uint32_t ROUTE_GETTER_TARGET_VA = 0x004E4D20;
inline constexpr uint32_t ROUTE_GETTER_CONTEXT_VA = 0x004CCCA6;
inline constexpr uint32_t ROUTE_GETTER_CALLEE_ENTRY_VA = 0x004E4D20;
inline constexpr uint32_t ROUTE_GETTER_SUCCESS_RET_VA = 0x004E4D3C;
inline constexpr uint32_t ROUTE_GETTER_NULL_RET_VA = 0x004E4D41;
inline constexpr uint32_t CLEAR_GATE_PATCH_VA = 0x004CCC6D;
inline constexpr uint32_t CLEAR_GATE_STORE_VA = 0x004CCC70;
inline constexpr uint32_t CLEAR_RECOVERY_PATCH_VA = 0x004CD19E;
inline constexpr uint32_t CLEAR_RECOVERY_STORE_VA = 0x004CD1A1;
inline constexpr uint32_t CLEAR_TIMER_PATCH_VA = 0x004CD1DB;
inline constexpr uint32_t CLEAR_TIMER_STORE_VA = 0x004CD1DE;
inline constexpr std::array<uint8_t, 14> CONTROLLER_CONTEXT = {
    0x56, 0x57, 0x8B, 0xF9, 0x8B, 0x4F, 0x14, 0xE8,
    0xB4, 0x12, 0x00, 0x00, 0x33, 0xF6
};
inline constexpr std::array<uint8_t, 15> SUBSTEP_BEGIN_CONTEXT = {
    0x8B, 0xCE, 0xD9, 0x5C, 0x24, 0x0C, 0xE8, 0x9E,
    0xFD, 0xFF, 0xFF, 0x8B, 0x7C, 0x24, 0x0C
};
inline constexpr std::array<uint8_t, 25> SUBSTEP_TAIL_CONTEXT = {
    0x57, 0x8B, 0xCE, 0xE8, 0x1C, 0x03, 0x00, 0x00,
    0x8B, 0xCE, 0xE8, 0xB5, 0x04, 0x00, 0x00,
    0x8B, 0xCE, 0xE8, 0x0E, 0x05, 0x00, 0x00,
    0x4B, 0x75, 0xA6
};
inline constexpr std::array<uint8_t, 16> ROUTE_GETTER_CONTEXT = {
    0x8D, 0x46, 0x54, 0x50, 0xE8, 0x11, 0x85, 0x01,
    0x00, 0x8B, 0xC8, 0xE8, 0x6A, 0x80, 0x01, 0x00
};
inline constexpr std::array<uint8_t, 5> ROUTE_GETTER_CALL = {
    0xE8, 0x6A, 0x80, 0x01, 0x00
};
inline constexpr std::array<uint8_t, 13> ROUTE_GETTER_CALLEE_ENTRY_CONTEXT = {
    0x8B, 0x44, 0x24, 0x04, 0x8B, 0x10, 0x8B, 0x41, 0x04,
    0x85, 0xC0, 0x74, 0x12
};
inline constexpr std::array<uint8_t, 3> ROUTE_GETTER_RET4_CONTEXT = {
    0xC2, 0x04, 0x00
};
inline constexpr std::array<uint8_t, 7> CLEAR_GATE_CONTEXT = {
    0x8B, 0x40, 0x08, 0xC6, 0x40, 0x33, 0x00
};
inline constexpr std::array<uint8_t, 7> CLEAR_RECOVERY_CONTEXT = {
    0x8B, 0x48, 0x08, 0xC6, 0x41, 0x33, 0x00
};
inline constexpr std::array<uint8_t, 6> CLEAR_TIMER_CONTEXT = {
    0x8B, 0x40, 0x08, 0x88, 0x48, 0x33
};
enum class ClearWriter : uint8_t { Unknown, GateRejected, RecoveryMode0, TimerExpired };
ClearWriter clear_writer(uint32_t store_va) noexcept;
const char* clear_writer_name(ClearWriter writer) noexcept;
struct PauseStateSample {
    bool known = false;
    bool paused = false;
    uint64_t sampled_tick_ms = 0;
};
struct PauseStateAtTime {
    bool known = false;
    bool paused = false;
    uint64_t age_ms = 0;
};
PauseStateAtTime pause_state_at(PauseStateSample sample, uint64_t now_ms,
                                uint64_t maximum_age_ms) noexcept;
const char* clear_context_failure_reason(bool gate_ok, bool recovery_ok,
                                        bool timer_ok) noexcept;
inline constexpr size_t MAX_TRACKS = 8;
inline constexpr size_t MAX_EVENTS = 64;
inline constexpr uint32_t SUBSTEP_WINDOW_EVENTS = 24;
inline constexpr uint8_t MAX_FLAGGED_SAMPLES = 4;
inline constexpr uint8_t SETTLING_SAMPLES = 3;

enum class OwnerClass : uint8_t { Unknown, HumanCandidate, AiCandidate };
OwnerClass owner_class(uint32_t player_type) noexcept;

struct NativeLinks {
    uint32_t controller = 0;
    uint32_t handle = 0;
    uint32_t handle_controller = 0;
    uint32_t actor = 0;
    uint32_t body = 0;
    uint32_t backing = 0;
    uint32_t wheel_records = 0;
    uint32_t player_type = 0;
};

bool pointer_shape(uint32_t pointer) noexcept;
bool route_getter_hook_requested(bool observer_enabled,
                                 bool road_preview_enabled) noexcept;
size_t physics_call_patch_count(bool include_route_getter) noexcept;
bool links_valid(const NativeLinks& links) noexcept;
bool same_identity(const NativeLinks& a, const NativeLinks& b) noexcept;
bool encode_relative_call(uint32_t site_va, uint32_t target_va,
                          std::array<uint8_t, 5>& output) noexcept;
bool context_bytes_match(const uint8_t* expected, size_t expected_size,
                         const uint8_t* actual, size_t actual_size) noexcept;
const char* context_failure_reason(bool controller_ok, bool substep_begin_ok,
                                   bool substep_tail_ok) noexcept;

enum class FlagEvent : uint8_t {
    None,
    FirstSetObserved,
    SetEdge,
    RepeatedSet,
    ClearEdge,
    Settling
};

struct FlagTracker {
    bool known = false;
    bool set = false;
    uint8_t captured_set_samples = 0;
    uint8_t settling_remaining = 0;
    uint64_t calls = 0;
    uint64_t set_calls = 0;
    uint64_t rises = 0;
    uint64_t clears = 0;
};

FlagEvent observe_flag(FlagTracker& tracker, uint8_t value) noexcept;
bool reserve_bounded_slot(size_t& used, size_t capacity) noexcept;
const char* flag_event_name(FlagEvent event) noexcept;

} // namespace gfx2::physics_probe
