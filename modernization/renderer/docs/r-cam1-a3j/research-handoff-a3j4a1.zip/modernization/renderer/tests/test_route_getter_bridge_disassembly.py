import re
import struct
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
BUILD = ROOT / "modernization" / "renderer" / ".build-msvc" / "Release"
DLL = BUILD / "d3d8.dll"
MAP = BUILD / "d3d8.map"
IMAGE_BASE = 0x10000000


def u16(data, offset):
    return struct.unpack_from("<H", data, offset)[0]


def u32(data, offset):
    return struct.unpack_from("<I", data, offset)[0]


def parse_image(data):
    if data[:2] != b"MZ":
        raise AssertionError("missing DOS header")
    pe = u32(data, 0x3C)
    if data[pe:pe + 4] != b"PE\0\0":
        raise AssertionError("missing PE signature")
    machine = u16(data, pe + 4)
    optional_size = u16(data, pe + 20)
    optional = pe + 24
    if u16(data, optional) != 0x010B:
        raise AssertionError("proxy is not PE32")
    image_base = u32(data, optional + 28)
    section_table = optional + optional_size
    sections = []
    for index in range(u16(data, pe + 6)):
        offset = section_table + index * 40
        name = data[offset:offset + 8].split(b"\0", 1)[0].decode("ascii")
        virtual_size, rva, raw_size, raw_offset = struct.unpack_from("<IIII", data, offset + 8)
        sections.append((name, rva, virtual_size, raw_offset, raw_size))

    def read_va(va, length):
        rva = va - image_base
        for name, section_rva, _, raw_offset, raw_size in sections:
            if name == ".text" and section_rva <= rva and rva + length <= section_rva + raw_size:
                offset = raw_offset + rva - section_rva
                return data[offset:offset + length]
        raise AssertionError(f"VA 0x{va:08X} is outside file-backed .text")

    return machine, image_base, read_va


def map_symbol_va(map_text, symbol):
    pattern = re.compile(
        rf"^\s*0001:[0-9a-fA-F]+\s+_{re.escape(symbol)}\s+([0-9a-fA-F]{{8}})(?:\s|$)",
        re.MULTILINE,
    )
    match = pattern.search(map_text)
    if not match:
        raise AssertionError(f"{symbol} missing from linker map")
    return int(match.group(1), 16)


class BuiltRouteGetterBridgeDisassembly(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not DLL.is_file() or not MAP.is_file():
            raise unittest.SkipTest("build the Win32 Release proxy before disassembly validation")
        cls.image = DLL.read_bytes()
        cls.map_text = MAP.read_text(errors="replace")
        cls.machine, cls.image_base, read_va = parse_image(cls.image)
        cls.read_va = staticmethod(read_va)
        cls.bridge_va = map_symbol_va(cls.map_text, "physics_probe_route_getter_bridge")
        cls.observer_va = map_symbol_va(cls.map_text, "physics_probe_route_after_getter")

    def test_production_bridge_is_pe32_i386_at_expected_base(self):
        self.assertEqual(self.machine, 0x014C)
        self.assertEqual(self.image_base, IMAGE_BASE)

    def test_production_bridge_forwards_argument_preserves_result_and_returns_ret4(self):
        # push [esp+4]; mov eax, retail target; call eax; pushfd; pushad;
        # push saved EAX to observer; restore state; ret 4.
        prefix = bytes.fromhex("FF 74 24 04 B8 20 4D 4E 00 FF D0 9C 60 8B 44 24 1C 50 E8")
        tail = bytes.fromhex("83 C4 04 61 9D C2 04 00")
        code = self.read_va(self.bridge_va, len(prefix) + 4 + len(tail))
        self.assertEqual(code[:len(prefix)], prefix)
        self.assertEqual(code[-len(tail):], tail)
        displacement = struct.unpack_from("<i", code, len(prefix))[0]
        observer_call_next = self.bridge_va + len(prefix) + 4
        self.assertEqual(observer_call_next + displacement, self.observer_va)


if __name__ == "__main__":
    unittest.main()
