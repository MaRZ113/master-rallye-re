import hashlib
import os
from pathlib import Path
import struct
import unittest


RETAIL_SHA256 = "bf8aef32407eb6552c05045b8abef149f32983cedd9503b865069b444c5f96b4"
RETAIL_SIZE = 3_121_214
IMAGE_BASE = 0x00400000

CONTEXTS = {
    "controller": (0x00443820, bytes.fromhex("56 57 8b f9 8b 4f 14 e8 b4 12 00 00 33 f6")),
    "substep_begin": (0x0043F8A7, bytes.fromhex("8b ce d9 5c 24 0c e8 9e fd ff ff 8b 7c 24 0c")),
    "substep_tail": (0x0043F8DC, bytes.fromhex(
        "57 8b ce e8 1c 03 00 00 8b ce e8 b5 04 00 00 "
        "8b ce e8 0e 05 00 00 4b 75 a6")),
    "route_getter": (0x004CCCA6, bytes.fromhex(
        "8d 46 54 50 e8 11 85 01 00 8b c8 e8 6a 80 01 00")),
    "clear_gate": (0x004CCC6D, bytes.fromhex("8b 40 08 c6 40 33 00")),
    "clear_recovery": (0x004CD19E, bytes.fromhex("8b 48 08 c6 41 33 00")),
    "clear_timer": (0x004CD1DB, bytes.fromhex("8b 40 08 88 48 33")),
}

CALLS = {
    "controller": (0x00443827, 0x00444AE0),
    "substep_begin": (0x0043F8AD, 0x0043F650),
    "substep_tail": (0x0043F8ED, 0x0043FE00),
    "route_getter": (0x004CCCB1, 0x004E4D20),
}

ROUTE_GETTER_CONTRACT = (
    0x004E4D20,
    bytes.fromhex(
        "8b 44 24 04 8b 10 8b 41 04 85 c0 74 12 8b 49 08 "
        "2b c8 c1 f9 02 3b d1 73 06 8b 04 90 c2 04 00 33 c0 c2 04 00"
    ),
)


def u16(data, offset):
    return struct.unpack_from("<H", data, offset)[0]


def u32(data, offset):
    return struct.unpack_from("<I", data, offset)[0]


def pe_text_map(data):
    if data[:2] != b"MZ":
        raise AssertionError("missing DOS MZ signature")
    pe = u32(data, 0x3C)
    if data[pe:pe + 4] != b"PE\0\0":
        raise AssertionError("missing PE signature")
    if u16(data, pe + 4) != 0x014C:
        raise AssertionError("retail image is not I386")
    section_count = u16(data, pe + 6)
    optional_size = u16(data, pe + 20)
    optional = pe + 24
    if u16(data, optional) != 0x010B:
        raise AssertionError("retail image is not PE32")
    image_base = u32(data, optional + 28)
    section_table = optional + optional_size
    sections = []
    for index in range(section_count):
        offset = section_table + 40 * index
        name = data[offset:offset + 8].split(b"\0", 1)[0].decode("ascii")
        virtual_size, virtual_address, raw_size, raw_offset = struct.unpack_from(
            "<IIII", data, offset + 8)
        sections.append((name, virtual_address, virtual_size, raw_offset, raw_size))
    text = next((s for s in sections if s[0] == ".text"), None)
    if image_base != IMAGE_BASE or text is None:
        raise AssertionError("unexpected image base or missing .text")

    def read_va(va, size):
        rva = va - image_base
        for name, virtual_address, virtual_size, raw_offset, raw_size in sections:
            if name == ".text" and virtual_address <= rva and rva + size <= virtual_address + raw_size:
                file_offset = raw_offset + rva - virtual_address
                return data[file_offset:file_offset + size]
        raise AssertionError(f"VA 0x{va:08X} is not backed by .text bytes")

    return read_va


class ExactRetailPhysicsProbeContexts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        candidates = []
        configured = os.environ.get("MR_PRISTINE_EXE")
        if configured:
            candidates.append(Path(configured))
        candidates.append(Path(r"D:\Game\Master Rallye Pristine\MRallye.exe"))
        cls.executable = next((path for path in candidates if path.is_file()), None)
        if cls.executable is None:
            raise unittest.SkipTest("set MR_PRISTINE_EXE to verify contexts against retail .text")
        cls.data = cls.executable.read_bytes()
        cls.read_va = staticmethod(pe_text_map(cls.data))

    def test_exact_pristine_identity(self):
        self.assertEqual(len(self.data), RETAIL_SIZE)
        self.assertEqual(hashlib.sha256(self.data).hexdigest(), RETAIL_SHA256)

    def test_complete_contexts_are_in_retail_text(self):
        for name, (va, expected) in CONTEXTS.items():
            with self.subTest(context=name):
                self.assertEqual(self.read_va(va, len(expected)), expected)

    def test_native_call_targets_are_in_retail_text(self):
        for name, (va, target) in CALLS.items():
            with self.subTest(call=name):
                raw = self.read_va(va, 5)
                self.assertEqual(raw[0], 0xE8)
                displacement = struct.unpack("<i", raw[1:])[0]
                self.assertEqual(va + 5 + displacement, target)

    def test_route_getter_register_and_stack_contract(self):
        va, expected = ROUTE_GETTER_CONTRACT
        self.assertEqual(self.read_va(va, len(expected)), expected)


if __name__ == "__main__":
    unittest.main()
