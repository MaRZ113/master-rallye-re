#include "physics_probe.hpp"

#include "physics_probe_model.hpp"
#include "provenance.hpp"
#include "race_epoch.hpp"
#include "state_tracker.hpp"

#include <tlhelp32.h>
#include <array>
#include <atomic>
#include <cstring>
#include <cstdio>
#include <iterator>
#include <sstream>
#include <intrin.h>

namespace gfx2 {
namespace {
using namespace physics_probe;

enum class EventKind : uint8_t {
    Controller,
    SubstepBeginBefore,
    SubstepBeginAfter,
    SubstepTailBefore,
    SubstepTailAfter
};

struct WheelSample {
    uint32_t address = 0;
    uint32_t word_120 = 0;
    uint8_t byte_04 = 0;
    uint8_t valid = 0;
};

struct Snapshot {
    NativeLinks links{};
    uint64_t qpc = 0;
    uint32_t thread_id = 0;
    int32_t participant_index = -1;
    uint32_t valid_mask = 0;
    uint8_t apply_flag = 0;
    uint8_t controller_byte_13 = 0;
    uint8_t controller_byte_18 = 0;
    uint8_t body_byte_04 = 0;
    std::array<uint32_t, 16> transform_bits{};
    std::array<uint32_t, 3> current_position_bits{};
    std::array<uint32_t, 3> previous_position_bits{};
    std::array<uint32_t, 6> body_opaque_11c_130{};
    std::array<WheelSample, 4> wheels{};
};

struct Event {
    uint64_t sequence = 0;
    EventKind kind = EventKind::Controller;
    FlagEvent flag_event = FlagEvent::None;
    uint32_t manager = 0;
    uint32_t loop_remaining = 0;
    bool has_before = false;
    bool has_after = false;
    bool has_baseline = false;
    Snapshot before{};
    Snapshot after{};
    Snapshot baseline{};
    size_t participant_count = 0;
    std::array<Snapshot, MAX_TRACKS> participants{};
};

struct Track {
    bool used = false;
    bool has_last = false;
    bool pending = false;
    uint32_t pending_thread = 0;
    uint64_t identity_generation = 0;
    NativeLinks identity{};
    FlagTracker flag{};
    FlagEvent pending_event = FlagEvent::None;
    bool pending_has_baseline = false;
    Snapshot last{};
    Snapshot pending_before{};
    Snapshot pending_baseline{};
    uint64_t overlap_calls = 0;
    uint64_t identity_changes = 0;
};

struct ProbeState {
    SRWLOCK lock = SRWLOCK_INIT;
    RacePatchBatch batch{};
    std::array<Track, MAX_TRACKS> tracks{};
    std::array<Event, MAX_EVENTS> events{};
    size_t event_count = 0;
    uint64_t event_sequence = 0;
    uint64_t dropped_events = 0;
    volatile LONG invalid_snapshots = 0;
    volatile LONG invalid_managers = 0;
    uint64_t dropped_tracks = 0;
    uint64_t substep_events = 0;
    uint64_t substep_windows = 0;
    uint32_t substep_budget = 0;
    volatile LONG substep_window_active = 0;
    volatile LONG enabled = 0;
    uint32_t leases = 0;
    uint32_t base = 0;
    bool installed = false;
    bool patch_intact = false;
    bool module_pinned = false;
    const char* reason = "not_requested";
    const char* release_reason = "not_released";
    HMODULE pinned_module = nullptr;
} probe;

class NativeMemory final : public PatchMemory {
public:
    bool read(void* dst, const void* src, size_t size) noexcept override {
        return safe_copy(dst, src, size);
    }
    bool write(void* dst, const void* src, size_t size) noexcept override {
        return safe_copy(dst, src, size);
    }
    bool protect(void* address, size_t size, DWORD protection, DWORD& prior) noexcept override {
        return VirtualProtect(address, size, protection, &prior) != FALSE;
    }
    bool flush(void* address, size_t size) noexcept override {
        return FlushInstructionCache(GetCurrentProcess(), address, size) != FALSE;
    }
} memory;

struct SuspendedThreads {
    std::array<HANDLE, 128> handles{};
    size_t count = 0;

    ~SuspendedThreads() {
        for (size_t i = count; i > 0; --i) {
            ResumeThread(handles[i - 1]);
            CloseHandle(handles[i - 1]);
        }
    }

    bool freeze(const RacePatchBatch& batch) noexcept {
        HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
        if (snapshot == INVALID_HANDLE_VALUE) return false;
        bool okay = true;
        THREADENTRY32 entry{};
        entry.dwSize = sizeof(entry);
        if (!Thread32First(snapshot, &entry)) {
            CloseHandle(snapshot);
            return false;
        }
        do {
            if (entry.th32OwnerProcessID != GetCurrentProcessId() ||
                entry.th32ThreadID == GetCurrentThreadId()) continue;
            if (count == handles.size()) { okay = false; break; }
            HANDLE thread = OpenThread(THREAD_SUSPEND_RESUME | THREAD_GET_CONTEXT |
                                       THREAD_QUERY_INFORMATION, FALSE, entry.th32ThreadID);
            if (!thread) { okay = false; break; }
            if (SuspendThread(thread) == DWORD(-1)) {
                CloseHandle(thread);
                okay = false;
                break;
            }
            handles[count++] = thread;
            CONTEXT context{};
            context.ContextFlags = CONTEXT_CONTROL;
            if (!GetThreadContext(thread, &context)) { okay = false; break; }
            for (size_t i = 0; i < batch.count; ++i) {
                const auto& site = batch.sites[i];
                const uintptr_t start = reinterpret_cast<uintptr_t>(site.address);
                if (context.Eip >= start && context.Eip < start + site.size) {
                    okay = false;
                    break;
                }
            }
            if (!okay) break;
        } while (Thread32Next(snapshot, &entry));
        CloseHandle(snapshot);
        return okay;
    }
};

bool add_address(uint32_t base, uint32_t offset, uint32_t& address) noexcept {
    if (base > UINT32_MAX - offset) return false;
    address = base + offset;
    return true;
}

bool read_u32(uint32_t base, uint32_t offset, uint32_t& value) noexcept {
    uint32_t address = 0;
    return add_address(base, offset, address) &&
           safe_copy(&value, reinterpret_cast<const void*>(address), sizeof(value));
}

bool read_u8(uint32_t base, uint32_t offset, uint8_t& value) noexcept {
    uint32_t address = 0;
    return add_address(base, offset, address) &&
           safe_copy(&value, reinterpret_cast<const void*>(address), sizeof(value));
}

bool read_bytes(uint32_t base, uint32_t offset, void* output, size_t size) noexcept {
    if (size > UINT32_MAX) return false;
    uint32_t address = 0;
    if (!add_address(base, offset, address) || size > UINT32_MAX - address) return false;
    return safe_copy(output, reinterpret_cast<const void*>(address), size);
}

bool capture_snapshot(uint32_t controller, Snapshot& out) noexcept {
    out = Snapshot{};
    out.thread_id = GetCurrentThreadId();
    LARGE_INTEGER qpc{};
    if (QueryPerformanceCounter(&qpc)) out.qpc = static_cast<uint64_t>(qpc.QuadPart);

    auto& links = out.links;
    links.controller = controller;
    if (!pointer_shape(controller) || !read_u32(controller, 0x6C, links.handle) ||
        !read_u32(links.handle, 0x14, links.handle_controller) ||
        !read_u32(links.handle, 0x08, links.actor) ||
        !read_u32(links.actor, 0x04, links.body) ||
        !read_u32(controller, 0x74, links.backing) ||
        !read_u32(links.handle, 0x0C, links.wheel_records) ||
        !read_u32(links.handle, 0x00, links.player_type) || !links_valid(links)) {
        return false;
    }

    if (read_u8(links.backing, 0x33, out.apply_flag)) out.valid_mask |= 1u << 0;
    if (read_u8(controller, 0x13, out.controller_byte_13) &&
        read_u8(controller, 0x18, out.controller_byte_18)) out.valid_mask |= 1u << 1;
    if (read_bytes(links.backing, 0x34, out.transform_bits.data(),
                   sizeof(out.transform_bits))) out.valid_mask |= 1u << 2;
    if (read_bytes(links.body, 0xA0, out.current_position_bits.data(),
                   sizeof(out.current_position_bits))) out.valid_mask |= 1u << 3;
    if (read_bytes(links.body, 0x144, out.previous_position_bits.data(),
                   sizeof(out.previous_position_bits))) out.valid_mask |= 1u << 4;
    if (read_bytes(links.body, 0x11C, out.body_opaque_11c_130.data(),
                   sizeof(out.body_opaque_11c_130))) out.valid_mask |= 1u << 5;
    if (read_u8(links.body, 0x04, out.body_byte_04)) out.valid_mask |= 1u << 6;

    bool all_wheels = true;
    for (uint32_t i = 0; i < out.wheels.size(); ++i) {
        const uint64_t wide = static_cast<uint64_t>(links.wheel_records) +
                              static_cast<uint64_t>(i) * 0x188u;
        if (wide > UINT32_MAX) { all_wheels = false; continue; }
        auto& wheel = out.wheels[i];
        wheel.address = static_cast<uint32_t>(wide);
        const bool byte_ok = read_u8(wheel.address, 0x04, wheel.byte_04);
        const bool word_ok = read_u32(wheel.address, 0x120, wheel.word_120);
        wheel.valid = static_cast<uint8_t>((byte_ok ? 1u : 0u) | (word_ok ? 2u : 0u));
        if (!byte_ok || !word_ok) all_wheels = false;
    }
    if (all_wheels) out.valid_mask |= 1u << 7;
    return true;
}

Track* find_track(uint32_t controller) noexcept {
    for (auto& track : probe.tracks)
        if (track.used && track.identity.controller == controller) return &track;
    return nullptr;
}

Track* get_track(const Snapshot& snapshot) noexcept {
    if (auto* found = find_track(snapshot.links.controller)) {
        if (!same_identity(found->identity, snapshot.links)) {
            const uint64_t next_generation = found->identity_generation + 1;
            const uint64_t changes = found->identity_changes + 1;
            *found = Track{};
            found->used = true;
            found->identity = snapshot.links;
            found->identity_generation = next_generation;
            found->identity_changes = changes;
        }
        return found;
    }
    for (auto& track : probe.tracks) {
        if (!track.used) {
            track = Track{};
            track.used = true;
            track.identity = snapshot.links;
            track.identity_generation = 1;
            return &track;
        }
    }
    ++probe.dropped_tracks;
    return nullptr;
}

void append_event(Event&& event) noexcept {
    if (!reserve_bounded_slot(probe.event_count, probe.events.size())) {
        ++probe.dropped_events;
        return;
    }
    event.sequence = ++probe.event_sequence;
    probe.events[probe.event_count - 1] = event;
}

bool verify_bytes(uint32_t base, uint32_t va, const uint8_t* expected, size_t size) noexcept {
    if (va < 0x00400000 || !size || size > 32) return false;
    std::array<uint8_t, 32> actual{};
    return safe_copy(actual.data(), reinterpret_cast<const void*>(base + va - 0x00400000), size) &&
           context_bytes_match(expected, size, actual.data(), size);
}

const char* verify_contexts(uint32_t base) noexcept {
    const bool controller_ok = verify_bytes(base, CONTROLLER_CONTEXT_VA,
                                            CONTROLLER_CONTEXT.data(), CONTROLLER_CONTEXT.size());
    const bool begin_ok = controller_ok && verify_bytes(base, SUBSTEP_BEGIN_CONTEXT_VA,
                                                        SUBSTEP_BEGIN_CONTEXT.data(), SUBSTEP_BEGIN_CONTEXT.size());
    const bool tail_ok = controller_ok && begin_ok && verify_bytes(base, SUBSTEP_TAIL_CONTEXT_VA,
                                                                   SUBSTEP_TAIL_CONTEXT.data(), SUBSTEP_TAIL_CONTEXT.size());
    return context_failure_reason(controller_ok, begin_ok, tail_ok);
}

void configure_call(size_t index, uint32_t base, uint32_t site_va, uint32_t target_va,
                    uintptr_t bridge, const std::array<uint8_t, 5>& expected) noexcept {
    auto& unit = probe.batch.sites[index];
    unit.address = reinterpret_cast<void*>(base + site_va - 0x00400000);
    unit.size = 5;
    for (size_t i = 0; i < expected.size(); ++i) unit.original[i] = expected[i];
    std::array<uint8_t, 5> encoded{};
    if (!encode_relative_call(site_va, static_cast<uint32_t>(bridge), encoded)) {
        // The production callsites and Win32 proxy share the 32-bit address space.
        unit.size = 0;
        return;
    }
    // The target in the EXE is intentionally checked separately from the
    // bridge displacement. This catches a mistaken site/target pairing.
    const uint32_t decoded_target = site_va + 5u +
        static_cast<uint32_t>(static_cast<int32_t>(
            static_cast<uint32_t>(expected[1]) |
            (static_cast<uint32_t>(expected[2]) << 8) |
            (static_cast<uint32_t>(expected[3]) << 16) |
            (static_cast<uint32_t>(expected[4]) << 24)));
    if (expected[0] != 0xE8 || decoded_target != target_va) {
        unit.size = 0;
        return;
    }
    for (size_t i = 0; i < encoded.size(); ++i) unit.replacement[i] = encoded[i];
}

bool batch_intact() noexcept {
    if (probe.batch.count != 3) return false;
    for (size_t i = 0; i < probe.batch.count; ++i) {
        const auto& site = probe.batch.sites[i];
        std::array<uint8_t, 5> actual{};
        if (!site.owned || !memory.read(actual.data(), site.address, site.size) ||
            std::memcmp(actual.data(), site.replacement.data(), site.size) != 0) return false;
    }
    return true;
}

uint32_t __cdecl controller_before(uint32_t controller) noexcept {
    if (InterlockedCompareExchange(&probe.enabled, 0, 0) == 0) return 0;
    Snapshot before{};
    if (!capture_snapshot(controller, before)) {
        InterlockedIncrement(&probe.invalid_snapshots);
        return 0;
    }

    AcquireSRWLockExclusive(&probe.lock);
    if (InterlockedCompareExchange(&probe.enabled, 0, 0) == 0 || !batch_intact()) {
        ReleaseSRWLockExclusive(&probe.lock);
        return 0;
    }
    Track* track = get_track(before);
    if (!track) {
        ReleaseSRWLockExclusive(&probe.lock);
        return 0;
    }
    if (track->pending) {
        ++track->overlap_calls;
        ReleaseSRWLockExclusive(&probe.lock);
        return 0;
    }

    const FlagEvent flag_event = observe_flag(track->flag, before.apply_flag);
    if (flag_event == FlagEvent::FirstSetObserved || flag_event == FlagEvent::SetEdge) {
        if (InterlockedCompareExchange(&probe.substep_window_active, 0, 0) == 0) {
            probe.substep_budget = SUBSTEP_WINDOW_EVENTS;
            InterlockedExchange(&probe.substep_window_active, 1);
            ++probe.substep_windows;
        }
    }

    track->pending = true;
    track->pending_thread = before.thread_id;
    track->pending_event = flag_event;
    track->pending_before = before;
    track->pending_has_baseline = track->has_last &&
        (flag_event == FlagEvent::FirstSetObserved || flag_event == FlagEvent::SetEdge);
    if (track->pending_has_baseline) track->pending_baseline = track->last;
    ReleaseSRWLockExclusive(&probe.lock);
    return controller;
}

void __cdecl controller_after(uint32_t controller) noexcept {
    if (!controller || InterlockedCompareExchange(&probe.enabled, 0, 0) == 0) return;
    Snapshot after{};
    const bool after_valid = capture_snapshot(controller, after);

    AcquireSRWLockExclusive(&probe.lock);
    Track* track = find_track(controller);
    if (!track || !track->pending || track->pending_thread != GetCurrentThreadId()) {
        if (track) ++track->overlap_calls;
        if (!after_valid) InterlockedIncrement(&probe.invalid_snapshots);
        ReleaseSRWLockExclusive(&probe.lock);
        return;
    }

    if (track->pending_event != FlagEvent::None) {
        Event event{};
        event.kind = EventKind::Controller;
        event.flag_event = track->pending_event;
        event.has_before = true;
        event.before = track->pending_before;
        event.has_after = after_valid;
        if (after_valid) event.after = after;
        event.has_baseline = track->pending_has_baseline;
        if (event.has_baseline) event.baseline = track->pending_baseline;
        append_event(std::move(event));
    }
    if (after_valid) {
        track->last = after;
        track->has_last = true;
        // Keep the flag tracker at its pre-call state so a clear that occurs
        // between controller iterations is visible as a transition next time.
    } else {
        InterlockedIncrement(&probe.invalid_snapshots);
        track->has_last = false;
    }
    track->pending = false;
    track->pending_thread = 0;
    track->pending_event = FlagEvent::None;
    track->pending_has_baseline = false;
    ReleaseSRWLockExclusive(&probe.lock);
}

size_t capture_manager(uint32_t manager, Snapshot* output, size_t capacity) noexcept {
    uint32_t begin = 0, end = 0;
    if (!pointer_shape(manager) || !read_u32(manager, 0x18, begin) ||
        !read_u32(manager, 0x1C, end) || !pointer_shape(begin) || end < begin ||
        ((end - begin) & 3u) != 0) {
        InterlockedIncrement(&probe.invalid_managers);
        return 0;
    }
    const uint32_t count = (end - begin) / 4;
    if (count > MAX_TRACKS || count > capacity) {
        InterlockedIncrement(&probe.invalid_managers);
        return 0;
    }
    size_t used = 0;
    for (uint32_t i = 0; i < count; ++i) {
        uint32_t handle = 0, controller = 0;
        if (!read_u32(begin + i * 4, 0, handle) || !pointer_shape(handle) ||
            !read_u32(handle, 0x14, controller) || !pointer_shape(controller)) {
            InterlockedIncrement(&probe.invalid_snapshots);
            continue;
        }
        Snapshot snapshot{};
        if (!capture_snapshot(controller, snapshot) || snapshot.links.handle != handle) {
            InterlockedIncrement(&probe.invalid_snapshots);
            continue;
        }
        snapshot.participant_index = static_cast<int32_t>(i);
        output[used++] = snapshot;
    }
    return used;
}

void substep_observe(EventKind kind, uint32_t manager, uint32_t loop_remaining) noexcept {
    if (InterlockedCompareExchange(&probe.enabled, 0, 0) == 0 ||
        InterlockedCompareExchange(&probe.substep_window_active, 0, 0) == 0) return;
    std::array<Snapshot, MAX_TRACKS> snapshots{};
    const size_t count = capture_manager(manager, snapshots.data(), snapshots.size());

    AcquireSRWLockExclusive(&probe.lock);
    if (InterlockedCompareExchange(&probe.enabled, 0, 0) == 0 ||
        InterlockedCompareExchange(&probe.substep_window_active, 0, 0) == 0) {
        ReleaseSRWLockExclusive(&probe.lock);
        return;
    }
    Event event{};
    event.kind = kind;
    event.manager = manager;
    event.loop_remaining = loop_remaining;
    event.participant_count = count;
    for (size_t i = 0; i < count; ++i) event.participants[i] = snapshots[i];
    append_event(std::move(event));
    ++probe.substep_events;
    if (probe.substep_budget) --probe.substep_budget;
    if (!probe.substep_budget || probe.event_count >= probe.events.size()) {
        InterlockedExchange(&probe.substep_window_active, 0);
    }
    ReleaseSRWLockExclusive(&probe.lock);
}

extern "C" uint32_t __cdecl physics_probe_controller_before(uint32_t controller) noexcept {
    return gfx2::controller_before(controller);
}
extern "C" void __cdecl physics_probe_controller_after(uint32_t controller) noexcept {
    gfx2::controller_after(controller);
}
extern "C" void __cdecl physics_probe_substep(uint32_t phase, uint32_t manager,
                                               uint32_t loop_remaining) noexcept {
    EventKind kind = EventKind::SubstepBeginBefore;
    switch (phase) {
    case 1: kind = EventKind::SubstepBeginAfter; break;
    case 2: kind = EventKind::SubstepTailBefore; break;
    case 3: kind = EventKind::SubstepTailAfter; break;
    default: break;
    }
    gfx2::substep_observe(kind, manager, loop_remaining);
}

extern "C" __declspec(naked) void physics_probe_controller_bridge() {
    __asm {
        pushfd
        pushad
        mov eax, ecx
        push eax
        call physics_probe_controller_before
        add esp, 4
        mov dword ptr [esp + 12], eax
        popad
        popfd
        push dword ptr [esp - 24]
        mov eax, 00444AE0h
        call eax
        pushfd
        pushad
        mov eax, dword ptr [esp + 36]
        push eax
        call physics_probe_controller_after
        add esp, 4
        popad
        popfd
        add esp, 4
        ret
    }
}

extern "C" __declspec(naked) void physics_probe_substep_begin_bridge() {
    __asm {
        pushfd
        pushad
        mov eax, ebx
        push eax
        push ecx
        push 0
        call physics_probe_substep
        add esp, 12
        popad
        popfd
        mov eax, 0043F650h
        call eax
        pushfd
        pushad
        mov eax, ebx
        push eax
        mov eax, esi
        push eax
        push 1
        call physics_probe_substep
        add esp, 12
        popad
        popfd
        ret
    }
}

extern "C" __declspec(naked) void physics_probe_substep_tail_bridge() {
    __asm {
        pushfd
        pushad
        mov eax, ebx
        push eax
        push ecx
        push 2
        call physics_probe_substep
        add esp, 12
        popad
        popfd
        mov eax, 0043FE00h
        call eax
        pushfd
        pushad
        mov eax, ebx
        push eax
        mov eax, esi
        push eax
        push 3
        call physics_probe_substep
        add esp, 12
        popad
        popfd
        ret
    }
}

const char* owner_name(uint32_t player_type) noexcept {
    switch (owner_class(player_type)) {
    case OwnerClass::HumanCandidate: return "human_candidate";
    case OwnerClass::AiCandidate: return "ai_candidate";
    default: return "unknown";
    }
}

const char* event_name(EventKind kind) noexcept {
    switch (kind) {
    case EventKind::Controller: return "controller_transform_consumer";
    case EventKind::SubstepBeginBefore: return "substep_begin_before_previous_sync";
    case EventKind::SubstepBeginAfter: return "substep_begin_after_previous_sync";
    case EventKind::SubstepTailBefore: return "substep_tail_before_final_stage";
    case EventKind::SubstepTailAfter: return "substep_tail_after_final_stage";
    default: return "unknown";
    }
}

std::string hex32(uint32_t value) {
    char text[11]{};
    sprintf_s(text, "0x%08X", value);
    return text;
}

void append_words(std::ostringstream& out, const uint32_t* words, size_t count) {
    out << '[';
    for (size_t i = 0; i < count; ++i) {
        if (i) out << ',';
        out << quote(hex32(words[i]));
    }
    out << ']';
}

void append_snapshot(std::ostringstream& out, const Snapshot& s) {
    out << "{\"identity_links_valid\":" << (links_valid(s.links) ? "true" : "false")
        << ",\"controller\":" << quote(hex32(s.links.controller))
        << ",\"handle\":" << quote(hex32(s.links.handle))
        << ",\"actor\":" << quote(hex32(s.links.actor))
        << ",\"body\":" << quote(hex32(s.links.body))
        << ",\"backing\":" << quote(hex32(s.links.backing))
        << ",\"wheel_records\":" << quote(hex32(s.links.wheel_records))
        << ",\"player_type\":" << s.links.player_type
        << ",\"owner_candidate\":" << quote(owner_name(s.links.player_type))
        << ",\"participant_index\":";
    if (s.participant_index < 0) out << "null"; else out << s.participant_index;
    out << ",\"thread_id\":" << s.thread_id << ",\"qpc\":" << s.qpc
        << ",\"valid_mask\":" << s.valid_mask
        << ",\"apply_flag_P_plus_0x33\":" << static_cast<unsigned>(s.apply_flag)
        << ",\"controller_byte_0x13\":" << static_cast<unsigned>(s.controller_byte_13)
        << ",\"controller_byte_0x18\":" << static_cast<unsigned>(s.controller_byte_18)
        << ",\"body_byte_0x04\":" << static_cast<unsigned>(s.body_byte_04)
        << ",\"transform_P_plus_0x34_raw_dwords\":";
    append_words(out, s.transform_bits.data(), s.transform_bits.size());
    out << ",\"body_current_position_0xA0_raw_dwords\":";
    append_words(out, s.current_position_bits.data(), s.current_position_bits.size());
    out << ",\"body_previous_position_0x144_raw_dwords\":";
    append_words(out, s.previous_position_bits.data(), s.previous_position_bits.size());
    out << ",\"body_opaque_0x11C_to_0x130_raw_dwords\":";
    append_words(out, s.body_opaque_11c_130.data(), s.body_opaque_11c_130.size());
    out << ",\"wheels\":[";
    for (size_t i = 0; i < s.wheels.size(); ++i) {
        if (i) out << ',';
        const auto& wheel = s.wheels[i];
        out << "{\"address\":" << quote(hex32(wheel.address))
            << ",\"byte_0x04\":" << static_cast<unsigned>(wheel.byte_04)
            << ",\"raw_word_0x120\":" << quote(hex32(wheel.word_120))
            << ",\"valid_mask\":" << static_cast<unsigned>(wheel.valid) << '}';
    }
    out << "]}";
}

void write_event(const Event& event) noexcept {
    try {
        std::ostringstream out;
        out << "{\"type\":\"physics_probe_event\",\"sequence\":" << event.sequence
            << ",\"event\":" << quote(event_name(event.kind));
        if (event.kind == EventKind::Controller) {
            out << ",\"flag_event\":" << quote(flag_event_name(event.flag_event))
                << ",\"before\":";
            append_snapshot(out, event.before);
            out << ",\"after\":";
            if (event.has_after) append_snapshot(out, event.after); else out << "null";
            out << ",\"baseline_before_flag\":";
            if (event.has_baseline) append_snapshot(out, event.baseline); else out << "null";
        } else {
            out << ",\"manager\":" << quote(hex32(event.manager))
                << ",\"loop_remaining\":" << event.loop_remaining
                << ",\"participants\":[";
            for (size_t i = 0; i < event.participant_count; ++i) {
                if (i) out << ',';
                append_snapshot(out, event.participants[i]);
            }
            out << ']';
        }
        out << '}';
        session().write(out.str());
    } catch (...) {}
}

void write_summary(bool patch_restored) noexcept {
    try {
        AcquireSRWLockExclusive(&probe.lock);
        std::ostringstream out;
        out << "{\"type\":\"physics_probe_summary\",\"phase\":\"R-CAM1-A3j.3\","
            << "\"read_only_game_data\":true,\"exact_retail_build\":true,"
            << "\"instrumented_call_sites\":["
            << "{\"va\":\"0x00443827\",\"rva\":\"0x00043827\",\"target_va\":\"0x00444AE0\"},"
            << "{\"va\":\"0x0043F8AD\",\"rva\":\"0x0003F8AD\",\"target_va\":\"0x0043F650\"},"
            << "{\"va\":\"0x0043F8ED\",\"rva\":\"0x0003F8ED\",\"target_va\":\"0x0043FE00\"}],"
            << "\"installed\":" << (probe.installed ? "true" : "false")
            << ",\"patch_restored\":" << (patch_restored ? "true" : "false")
            << ",\"module_pinned\":" << (probe.module_pinned ? "true" : "false")
            << ",\"reason\":" << quote(probe.reason)
            << ",\"release_reason\":" << quote(probe.release_reason)
            << ",\"qpc_frequency\":";
        LARGE_INTEGER frequency{};
        QueryPerformanceFrequency(&frequency);
        out << static_cast<uint64_t>(frequency.QuadPart)
            << ",\"counts\":{\"tracked_controllers\":";
        size_t tracks_used = 0;
        uint64_t updates = 0, set_calls = 0, rises = 0, clears = 0, overlaps = 0, identity_changes = 0;
        for (const auto& track : probe.tracks) {
            if (!track.used) continue;
            ++tracks_used;
            updates += track.flag.calls;
            set_calls += track.flag.set_calls;
            rises += track.flag.rises;
            clears += track.flag.clears;
            overlaps += track.overlap_calls;
            identity_changes += track.identity_changes;
        }
        out << tracks_used << ",\"controller_updates\":" << updates
            << ",\"flag_set_consumer_calls\":" << set_calls
            << ",\"flag_rises_observed\":" << rises
            << ",\"flag_clears_observed\":" << clears
            << ",\"same_controller_overlap_calls\":" << overlaps
            << ",\"identity_changes\":" << identity_changes
            << ",\"invalid_native_snapshots\":" << static_cast<uint32_t>(probe.invalid_snapshots)
            << ",\"invalid_physics_managers\":" << static_cast<uint32_t>(probe.invalid_managers)
            << ",\"dropped_tracks\":" << probe.dropped_tracks
            << ",\"dropped_events\":" << probe.dropped_events
            << ",\"substep_events\":" << probe.substep_events
            << ",\"substep_windows_opened\":" << probe.substep_windows
            << ",\"events_written\":" << probe.event_count << "},\"controllers\":[";
        bool first = true;
        for (const auto& track : probe.tracks) {
            if (!track.used) continue;
            if (!first) out << ',';
            first = false;
            out << "{\"controller\":" << quote(hex32(track.identity.controller))
                << ",\"handle\":" << quote(hex32(track.identity.handle))
                << ",\"body\":" << quote(hex32(track.identity.body))
                << ",\"player_type\":" << track.identity.player_type
                << ",\"owner_candidate\":" << quote(owner_name(track.identity.player_type))
                << ",\"identity_generation_local\":" << track.identity_generation
                << ",\"updates\":" << track.flag.calls
                << ",\"flag_set_calls\":" << track.flag.set_calls
                << ",\"flag_rises\":" << track.flag.rises
                << ",\"flag_clears\":" << track.flag.clears
                << ",\"overlap_calls\":" << track.overlap_calls
                << ",\"identity_changes\":" << track.identity_changes << '}';
        }
        out << "]}";
        ReleaseSRWLockExclusive(&probe.lock);
        session().write(out.str());
        for (size_t i = 0; i < probe.event_count; ++i) write_event(probe.events[i]);
    } catch (...) {
        ReleaseSRWLockExclusive(&probe.lock);
    }
}

bool pin_probe_module() noexcept {
    if (probe.module_pinned) return true;
    HMODULE module = nullptr;
    const auto address = reinterpret_cast<uintptr_t>(&physics_probe_controller_bridge);
    if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,
                            reinterpret_cast<LPCWSTR>(address), &module)) return false;
    probe.pinned_module = module;
    probe.module_pinned = true;
    return true;
}

void configure_batch(uint32_t base) noexcept {
    probe.batch = RacePatchBatch{};
    probe.batch.count = 3;
    configure_call(0, base, CONTROLLER_CALL_VA, CONTROLLER_CALL_TARGET_VA,
                   reinterpret_cast<uintptr_t>(&physics_probe_controller_bridge),
                   {0xE8, 0xB4, 0x12, 0x00, 0x00});
    configure_call(1, base, SUBSTEP_BEGIN_CALL_VA, SUBSTEP_BEGIN_TARGET_VA,
                   reinterpret_cast<uintptr_t>(&physics_probe_substep_begin_bridge),
                   {0xE8, 0x9E, 0xFD, 0xFF, 0xFF});
    configure_call(2, base, SUBSTEP_TAIL_CALL_VA, SUBSTEP_TAIL_TARGET_VA,
                   reinterpret_cast<uintptr_t>(&physics_probe_substep_tail_bridge),
                   {0xE8, 0x0E, 0x05, 0x00, 0x00});
}

void note_setup(bool requested, bool exact, bool installed, const char* reason) noexcept {
    try {
        session().write("{\"type\":\"physics_probe_setup\",\"phase\":\"R-CAM1-A3j.3\","
                        "\"requested\":" + std::string(requested ? "true" : "false") +
                        ",\"exact_retail_build\":" + (exact ? "true" : "false") +
                        ",\"installed\":" + (installed ? "true" : "false") +
                        ",\"read_only_game_data\":true,\"reason\":" + quote(reason) + "}");
    } catch (...) {}
}

} // namespace

PhysicsProbeSettings read_physics_probe_settings(const std::wstring& path) noexcept {
    PhysicsProbeSettings settings;
    try {
        wchar_t buffer[32]{};
        const DWORD length = GetPrivateProfileStringW(L"PhysicsObserver", L"Enabled", L"0",
                                                       buffer, static_cast<DWORD>(std::size(buffer)),
                                                       path.c_str());
        settings.raw_value = length >= std::size(buffer) - 1 ? "__TRUNCATED_INVALID__" : utf8(buffer);
        bool parsed = false;
        if (!parse_config_boolean(settings.raw_value, parsed)) {
            settings.valid = false;
            settings.enabled = false;
        } else {
            settings.enabled = parsed;
        }
    } catch (...) {
        settings.valid = false;
        settings.enabled = false;
        settings.raw_value = "__READ_FAILED__";
    }
    return settings;
}

bool attach_physics_probe(bool exact_retail, const PhysicsProbeSettings& settings) noexcept {
    try {
        session().write("{\"type\":\"physics_probe_config\",\"phase\":\"R-CAM1-A3j.3\","
                        "\"enabled_raw\":" + quote(settings.raw_value) +
                        ",\"valid\":" + (settings.valid ? "true" : "false") +
                        ",\"requested\":" + (settings.enabled ? "true" : "false") + "}");
    } catch (...) {}
    if (!settings.enabled) {
        note_setup(false, exact_retail, false, settings.valid ? "disabled_by_default_or_config" : "invalid_config_disabled");
        return false;
    }
    if (!settings.valid) {
        note_setup(true, exact_retail, false, "invalid_config_disabled");
        return false;
    }
    if (!exact_retail) {
        note_setup(true, false, false, "exact_pristine_build_required");
        return false;
    }

    AcquireSRWLockExclusive(&probe.lock);
    if (probe.leases && probe.installed && batch_intact()) {
        ++probe.leases;
        InterlockedExchange(&probe.enabled, 1);
        ReleaseSRWLockExclusive(&probe.lock);
        note_setup(true, true, true, "existing_probe_lease");
        return true;
    }
    if (probe.leases) {
        ReleaseSRWLockExclusive(&probe.lock);
        note_setup(true, true, false, "probe_lease_state_inconsistent");
        return false;
    }

    if (probe.installed && batch_intact()) {
        probe.leases = 1;
        probe.reason = "reactivated_owned_hook";
        InterlockedExchange(&probe.enabled, 1);
        ReleaseSRWLockExclusive(&probe.lock);
        note_setup(true, true, true, "reactivated_owned_hook");
        return true;
    }
    if (probe.batch.owned()) {
        probe.reason = "partial_or_foreign_hook_requires_process_exit";
        ReleaseSRWLockExclusive(&probe.lock);
        note_setup(true, true, false, probe.reason);
        return false;
    }

    probe.tracks = {};
    probe.events = {};
    probe.event_count = 0;
    probe.event_sequence = 0;
    probe.dropped_events = 0;
    probe.invalid_snapshots = 0;
    probe.invalid_managers = 0;
    probe.dropped_tracks = 0;
    probe.substep_events = 0;
    probe.substep_windows = 0;
    probe.substep_budget = 0;
    InterlockedExchange(&probe.substep_window_active, 0);

    probe.base = static_cast<uint32_t>(reinterpret_cast<uintptr_t>(GetModuleHandleW(nullptr)));
    if (probe.base != 0x00400000 || !pin_probe_module()) {
        probe.reason = "image_base_or_module_pin_failed";
        ReleaseSRWLockExclusive(&probe.lock);
        note_setup(true, true, false, probe.reason);
        return false;
    }
    configure_batch(probe.base);
    bool installed = false;
    {
        SuspendedThreads suspended;
        if (!suspended.freeze(probe.batch)) {
            probe.reason = "thread_quiescence_check_failed";
        } else {
            const char* context_failure = verify_contexts(probe.base);
            if (context_failure) {
                probe.reason = context_failure;
            } else {
                installed = probe.batch.install(memory);
                if (!installed) {
                    probe.reason = "exact_callsite_mismatch_or_patch_failed";
                    if (probe.batch.owned()) {
                        probe.batch.remove(memory);
                        if (probe.batch.owned()) probe.reason = "partial_hook_remains_disabled_module_pinned";
                    }
                }
            }
        }
    }
    if (!installed) {
        probe.installed = false;
        probe.patch_intact = probe.batch.owned();
        InterlockedExchange(&probe.enabled, 0);
        ReleaseSRWLockExclusive(&probe.lock);
        note_setup(true, true, false, probe.reason);
        return false;
    }

    probe.installed = true;
    probe.patch_intact = true;
    probe.reason = "exact_callsites_installed_read_only";
    probe.leases = 1;
    InterlockedExchange(&probe.enabled, 1);
    ReleaseSRWLockExclusive(&probe.lock);
    note_setup(true, true, true, probe.reason);
    return true;
}

void release_physics_probe() noexcept {
    AcquireSRWLockExclusive(&probe.lock);
    if (!probe.leases) {
        ReleaseSRWLockExclusive(&probe.lock);
        return;
    }
    --probe.leases;
    if (probe.leases) {
        ReleaseSRWLockExclusive(&probe.lock);
        return;
    }
    InterlockedExchange(&probe.enabled, 0);
    probe.release_reason = "device_release_disable_and_restore";
    ReleaseSRWLockExclusive(&probe.lock);

    bool restored = false;
    if (probe.installed && probe.batch.owned()) {
        {
            SuspendedThreads suspended;
            if (suspended.freeze(probe.batch)) restored = probe.batch.remove(memory);
        }
    }

    AcquireSRWLockExclusive(&probe.lock);
    probe.patch_intact = !restored && probe.batch.owned();
    if (restored) {
        probe.installed = false;
        probe.release_reason = "hook_restored";
    } else if (probe.batch.owned()) {
        probe.release_reason = "restore_not_safe_or_foreign_patch;disabled_and_module_pinned";
    } else {
        probe.installed = false;
        probe.release_reason = "hook_already_absent";
    }
    ReleaseSRWLockExclusive(&probe.lock);
    write_summary(restored);
}

} // namespace gfx2
