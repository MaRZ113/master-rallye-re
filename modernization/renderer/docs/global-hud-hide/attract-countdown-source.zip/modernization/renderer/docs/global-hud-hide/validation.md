# Global HUD Hide — validation

## Attract Demo and startup countdown diagnosis

The supplied 12 October captures exposed two additional HUD-only gaps. In Attract Demo, the committed scene is `Hud/AttractMode`, parented to a successful `Racetest/france2` load, with typed `Race/AttractMode=1`, `Race/Type=14`, four readable live participants, and a successful child commit. The existing classifier admitted only `Hud/Hud0`; moreover, the Attract child was treated as a new race generation, so the completed owner proof no longer correlated. This made the exact Attract HUD fail open and could leave the next context unknown until another supported race lifecycle completed.

During the start countdown, the capture shows `Hud/Hud0`, `RaceState=1`, and SceneManager countdown value `1`. The observer correctly labeled RaceState 1 as a startup transition, but the HUD gate reused the stricter participant-state rule and rejected it. HUD suppression accepts phases 0/1/2 after all participant values have been read and validated; phase 1 additionally requires the live SceneManager countdown to be positive and is reported as `gameplay_start_countdown`. This relaxation is confined to the visual HUD context. Camera/freecam and race-write certificates still use their original stricter checks.

Attract admission is separate: the lifecycle must pair the exact `Hud/AttractMode` child and its data source with the successful track root and current live owner; the typed race fields must identify the offline Attract mode and participant count must match. It does not require the absent pause Broker entry, but it still requires the exact D3D UI consumer, current device/render thread, verified resource identity, and FVF/primitive signature. F10 lifecycle records now include each scene request's native origin to validate the captured Attract route at runtime.

The source frames diagnose these causes; they do not establish a visual pass for the new candidate.

## Replay diagnosis

The latest supplied F10 frame was captured during replay. Its trace showed that the H preference changed, but `hud_hide` stayed fail-open with `current_ui_context=unknown`, `policy_ready=false`, and zero suppressed draws. The race snapshot identified a committed `RaceTest/France1` root with its `Hud/Hud0` child, one local participant in running state, no network players/sync, no attract mode, and `Race/PlaybackReplay=1`.

The rejection came from sharing the camera/freecam race-context gate with HUD visibility. That gate intentionally rejects `PlaybackReplay`, so the race HUD policy never reached its already verified UI packet draw checks. The fix adds a separate HUD-only context check: it requires the replay value to be a typed boolean exactly equal to 1, then reruns the strict offline, one-player, owner, participant, course, and Hud0 checks with only that replay bit normalized for the shared base validator. Ghost/network activity, malformed or missing fields, and other unsupported context still fail open. Attract Demo is now admitted only through its separately documented `Hud/AttractMode` lifecycle and typed context. The camera/freecam certificate remains unchanged and continues to reject replay and Attract mode.

Active, certified replay can now suppress only the existing verified race-HUD packet draws. Paused replay remains visible so its interactive pause UI is preserved. Frontend, loading, results, unknown scenes, and uncertain ownership remain fail-open. The latest trace diagnosed the cause; it is not a post-fix runtime pass.

## Automated checks

- `python modernization/renderer/tools/build.py`: Win32 Release build completed; native CTest passed 24/24, including Attract HUD lifecycle admission, startup-phase HUD admission, strict camera-certificate rejection, paused replay preservation, lifecycle Reset handling, and existing ABI contracts.
- `python -m unittest discover -s modernization/renderer/tests -v`: 193 tests passed (132.972 seconds); after the final draw/context identity check, the affected race-context and visual-trace Python tests passed 16/16.
- `python -m unittest discover -s tests/synthetic -v`: 630 tests passed.
- `python -m compileall -q modernization`: passed.
- `python modernization/renderer/tools/verify_proxy.py modernization/renderer/.build-msvc/Release/d3d8.dll`: valid PE32/I386 DLL; direct exports `Direct3DCreate8`, `ValidatePixelShader`, and `ValidateVertexShader`; imports `bcrypt.dll`, `USER32.dll`, and `KERNEL32.dll`; no recursive D3D8 import. SHA256: `c652f800de341553077d56752bdbedda3f9b1edc4da4bdbe989b52a13536282e`; size: 2,291,712 bytes.
- `git diff --check`: passed; Git emitted CRLF normalization notices for existing Windows-style files, with no whitespace errors.

## Runtime status

The candidate is **ready for human runtime testing**, not visually confirmed. Install the DLL using the existing local procedure and test the start countdown, ordinary gameplay, Attract Demo, active replay, pause preservation, and menu protection in [runtime-handoff.md](runtime-handoff.md). On hidden frames, expect `gameplay_start_countdown` with `startup_countdown=true`, `attract_demo` with `attract_mode=true`, or `replay_running` with `replay_mode=true`, plus positive `suppressed_hud_draws` when an eligible draw occurs. Static tests cannot establish that every visible overlay belongs to the admitted native packet stream.
