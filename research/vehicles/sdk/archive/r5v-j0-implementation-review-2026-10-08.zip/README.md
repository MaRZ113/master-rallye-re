# R5V-J.0 Implementation Review Package

This package contains the source-level J.0 Generic Addon Vehicle SDK foundation, its V1 schema and two metadata-only examples, focused tests and fixture, project metadata, J.0 status/architecture documents, exact verification output, and the derived evidence/reference-plan contents from the previously validated evidence archive. It contains no retail or patched executable, game assets, raw Broker dumps, save files, screenshots, Ghidra databases, or runtime package.

## Source snapshot

- Repository: master-rallye-re-vehicles
- Branch: research/vehicles
- Source commit: 0c3bfdf305ad75251d782251a4e42648e8ab4a94 (feat: add generic addon vehicle SDK offline foundation)
- Source worktree status at capture: clean. The Git snapshot is the implementation commit before this review ZIP is added.
- The original derived-evidence archive remains unchanged in the repository; its payload/index members are expanded under evidence/previous/ here so all package contents remain text/JSON.
- archive-index.json at package root lists the path, byte size, and SHA256 of every payload file. The index does not hash itself. The previous archive's original index is preserved under evidence/previous/archive-index.json.

## Reproduce the offline two-addon plan

Use a full checkout of master-rallye-re-vehicles at the source commit above. The archive carries all J.0-added/modified files, but existing parser/packaging modules are supplied by the repository baseline. Python 3.10 or newer is required; core J.0 code uses the standard library and repository modules. No game assets are needed for this metadata-only reproduction.

From the checkout root in PowerShell, run:

    $env:PYTHONPATH = 'src'
    python tools\mrtool.py addon validate --manifest research\vehicles\sdk\examples\mercedes-ml320.json --manifest research\vehicles\sdk\examples\r5v-qualifier-t2.json --capabilities research\vehicles\sdk\capabilities\retail-2001.json
    python tools\mrtool.py addon build --manifest research\vehicles\sdk\examples\mercedes-ml320.json --manifest research\vehicles\sdk\examples\r5v-qualifier-t2.json --capabilities research\vehicles\sdk\capabilities\retail-2001.json --output .research-output\vehicles\sdk\independent-review-rebuild
    python tools\mrtool.py addon verify .research-output\vehicles\sdk\independent-review-rebuild
    Get-FileHash .research-output\vehicles\sdk\independent-review-rebuild\addon-plan.json -Algorithm SHA256

Expected plan SHA256: 357d3cf10f32b63af27d28c23a858197d7eedbd0d7ef79e4deb2a63a6b170989. The output explicitly has runtime_installable=false; this is not a game-ready mod. The captured reference-plan/ files are byte-checked against the reproducible two-addon build.

## Reproduce the focused tests

    $env:PYTHONPATH = 'src'
    python -m unittest discover -s tests\synthetic -p test_addon_sdk.py -v
    python -m compileall -q src tools tests

For the complete repository synthetic suite use:

    $env:PYTHONPATH = 'src'
    python -m unittest discover -s tests\synthetic -v

Exact commands, logs, exit codes, and pass/fail/skip counts are under validation-output/; the machine-readable summary is test-report.json. The captured results are 382/382 full-suite tests passing and 14/14 focused SDK tests passing, with zero failures or skips.
